@echo off
setlocal
cd /d "%~dp0"
title AI Assistant
set PYTHONUTF8=1

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo  Not set up yet - double-click setup.bat first.
    echo.
    pause
    exit /b 1
)

REM Start the tool server in its own minimised window, give it a moment to boot,
REM then start the voice assistant here. Close both windows to stop.
start "Assistant tool server" /min ".venv\Scripts\python.exe" server.py
timeout /t 4 /nobreak >nul

".venv\Scripts\python.exe" assistant.py

echo.
echo  The assistant has stopped. Remember to close the "Assistant tool server" window too.
pause
