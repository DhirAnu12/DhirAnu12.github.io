"""
HUD (web-based) — full-screen overlay window using pywebview.
"""

import webview
import threading
import time
import os
import json
from datetime import datetime

from friday.db import reminders as reminders_db
from friday.scheduling import service as schedule_service
from friday.scheduling.nl_commands import _resolve_target_block
from friday.settings import ASSISTANT_NAME, settings

hud_window = None
_current_state = {
    "speaking": False,
    "muted": False,
    "time": "",
    "date": "",
    "status": "Active",
    "reminders": "No reminders",
    "schedule": None,
}

REMINDERS_POLL_SECONDS = 20  # matches assistant.py's check_reminders_loop cadence
SCHEDULE_POLL_SECONDS = 20


def _clock_updater():
    while True:
        now = datetime.now()
        _current_state["time"] = now.strftime("%I:%M %p")
        _current_state["date"] = now.strftime("%A, %B %d")
        push_update()
        time.sleep(1)


def _format_reminders(rows: list[dict]) -> str:
    if not rows:
        return "No reminders"
    lines = [f"{reminders_db.parse_due(r['due']).strftime('%I:%M %p')} — {r['text']}" for r in rows[:5]]
    return "\n".join(lines)


def _reminders_updater():
    """Polls the local reminders store directly — independent of whichever
    process (assistant.py or the MCP server) actually set/changed a reminder."""
    while True:
        try:
            todays = reminders_db.list_todays_reminders()
            set_reminders_text(_format_reminders(todays))
        except Exception:
            pass  # keep showing the last-known text rather than clearing it
        time.sleep(REMINDERS_POLL_SECONDS)


def _fmt_hm(dt: datetime) -> str:
    return dt.strftime("%I:%M %p").lstrip("0")


def _label(block, tasks_by_id: dict) -> str:
    if block.task_id and block.task_id in tasks_by_id:
        return tasks_by_id[block.task_id].title
    if block.reason and block.reason.startswith("Fixed commitment: "):
        return block.reason[len("Fixed commitment: "):]
    return block.block_type.capitalize()


def _build_schedule_state() -> dict:
    """Compact snapshot for the HUD — same underlying data as the full Today
    page (friday/scheduling/service.py.get_today_schedule), just trimmed down
    to what's useful while actively working. Runs in-process (desktop app),
    so this calls the service layer directly rather than hitting the REST API."""
    result = schedule_service.get_today_schedule()
    now = datetime.now()
    tasks_by_id = {t.id: t for t in schedule_service.list_tasks(include_all=True)}
    task_blocks = [b for b in result.blocks if b.block_type == "task"]

    active = next(
        (b for b in result.blocks if b.start_time <= now < b.end_time and b.status not in ("completed", "skipped")),
        None,
    )
    upcoming = sorted((b for b in result.blocks if b.start_time > now), key=lambda b: b.start_time)[:5]

    completed_minutes = sum(b.duration_minutes for b in task_blocks if b.status == "completed")
    total_minutes = sum(b.duration_minutes for b in task_blocks)
    progress_pct = round((completed_minutes / total_minutes) * 100) if total_minutes else 0

    current = None
    if active:
        current = {
            "id": active.id,
            "title": _label(active, tasks_by_id),
            "start": _fmt_hm(active.start_time),
            "end": _fmt_hm(active.end_time),
            "minutes_left": max(int((active.end_time - now).total_seconds() // 60), 0),
            "locked": active.locked,
            "is_task": active.block_type == "task",
        }

    recent = schedule_service.get_history(limit=2)

    return {
        "current": current,
        "timeline": [
            {"title": _label(b, tasks_by_id), "start": _fmt_hm(b.start_time), "end": _fmt_hm(b.end_time), "block_type": b.block_type}
            for b in upcoming
        ],
        "progress_pct": progress_pct,
        "at_risk": [t.title for t in result.at_risk_tasks[:3]],
        "next_action": result.recommended_next_action or "",
        "recent_change": recent[0]["explanation"] if recent else "",
    }


def _refresh_schedule() -> dict:
    try:
        state = _build_schedule_state()
    except Exception:
        return {"error": "Could not load schedule."}
    _current_state["schedule"] = state
    push_update()
    return state


def _schedule_updater():
    while True:
        try:
            _refresh_schedule()
        except Exception:
            pass
        time.sleep(SCHEDULE_POLL_SECONDS)


def push_update():
    if hud_window:
        try:
            js = f"updateHUD({json.dumps(_current_state)})"
            hud_window.evaluate_js(js)
        except Exception:
            pass


def set_speaking(is_speaking: bool):
    _current_state["speaking"] = is_speaking
    _current_state["status"] = "Speaking" if is_speaking else "Active"
    push_update()


def set_muted(is_muted: bool):
    _current_state["muted"] = is_muted
    _current_state["status"] = "Muted" if is_muted else "Active"
    push_update()


def set_reminders_text(text: str):
    _current_state["reminders"] = text
    push_update()


# ---------------------------------------------------------------------------
# HUD controls — exposed to hud_display.html's JS as pywebview.api.<method>
# ---------------------------------------------------------------------------

class HudAPI:
    """Every method here mutates via friday/scheduling/service.py (never touches
    the storage files directly) and refreshes the HUD's schedule state immediately
    afterward, so the panel doesn't wait for the next poll tick."""

    def _current_or_next_block_id(self):
        block_id, error = _resolve_target_block("")
        return block_id, error

    def start_current_task(self):
        block_id, error = self._current_or_next_block_id()
        if error:
            return {"error": error}
        schedule_service.start_block(block_id)
        return _refresh_schedule()

    def pause_current_task(self):
        block_id, error = self._current_or_next_block_id()
        if error:
            return {"error": error}
        schedule_service.pause_block(block_id)
        return _refresh_schedule()

    def complete_current_task(self, actual_minutes=None):
        block_id, error = self._current_or_next_block_id()
        if error:
            return {"error": error}
        schedule_service.complete_block(block_id, actual_minutes=actual_minutes)
        return _refresh_schedule()

    def skip_current_task(self, disposition="backlog"):
        block_id, error = self._current_or_next_block_id()
        if error:
            return {"error": error}
        schedule_service.skip_block(block_id, disposition=disposition)
        return _refresh_schedule()

    def extend_current_task(self, extra_minutes):
        block_id, error = self._current_or_next_block_id()
        if error:
            return {"error": error}
        schedule_service.extend_block(block_id, int(extra_minutes))
        return _refresh_schedule()

    def lock_current_task(self):
        block_id, error = self._current_or_next_block_id()
        if error:
            return {"error": error}
        current = _current_state.get("schedule", {}).get("current") or {}
        schedule_service.lock_block(block_id, locked=not current.get("locked", False))
        return _refresh_schedule()

    def replan_day(self):
        schedule_service.replan_now(detail="Replanned from the HUD.")
        return _refresh_schedule()

    def get_full_schedule_view(self):
        """All of today's blocks (not just the compact panel's next-5), for the
        HUD's own in-overlay expand panel."""
        try:
            result = schedule_service.get_today_schedule()
            tasks_by_id = {t.id: t for t in schedule_service.list_tasks(include_all=True)}
            blocks = sorted(result.blocks, key=lambda b: b.start_time)
            return {
                "blocks": [
                    {
                        "id": b.id,
                        "title": _label(b, tasks_by_id),
                        "start": _fmt_hm(b.start_time),
                        "end": _fmt_hm(b.end_time),
                        "block_type": b.block_type,
                        "status": b.status,
                        "locked": b.locked,
                    }
                    for b in blocks
                ],
            }
        except Exception as e:
            return {"error": f"Couldn't load the schedule: {e}"}

    def get_planner_view(self):
        """To-dos + habits, for the HUD's in-overlay expand panel — read view
        with quick-complete only; add new tasks by voice ("add a task to...")."""
        try:
            todos = schedule_service.list_todos()
            habits = schedule_service.list_habits()
            return {
                "todos": [{"id": t.id, "title": t.title, "priority": t.priority} for t in todos],
                "habits": [
                    {
                        "task_id": h["task"].id,
                        "title": h["task"].title,
                        "streak": h["streak"],
                        "done_today": h["done_today"],
                    }
                    for h in habits
                ],
            }
        except Exception as e:
            return {"error": f"Couldn't load the planner: {e}"}

    def complete_block_now(self, block_id):
        try:
            schedule_service.complete_block(int(block_id))
        except Exception as e:
            return {"error": str(e)}
        _refresh_schedule()
        return self.get_full_schedule_view()

    def complete_task_now(self, task_id):
        try:
            schedule_service.complete_task_directly(int(task_id))
        except Exception as e:
            return {"error": str(e)}
        _refresh_schedule()
        return self.get_planner_view()


def create_window():
    """Creates the webview window object. Call this before start_blocking()."""
    global hud_window
    html_path = os.path.join(os.path.dirname(__file__), "hud_display.html")
    hud_window = webview.create_window(
        ASSISTANT_NAME,
        html_path,
        transparent=True,
        frameless=True,
        on_top=True,
        width=settings["hud"]["width"],    # set in settings.toml
        height=settings["hud"]["height"],
        x=0, y=0,
        resizable=False,
        js_api=HudAPI(),
    )
    # Fill in the assistant's name once the page has loaded.
    hud_window.events.loaded += lambda: hud_window.evaluate_js(
        f"setAssistantName({json.dumps(ASSISTANT_NAME)})"
    )
    return hud_window


def start_blocking():
    """Starts the webview event loop. MUST be called on the main thread — blocks forever."""
    clock_thread = threading.Thread(target=_clock_updater, daemon=True)
    clock_thread.start()

    reminders_thread = threading.Thread(target=_reminders_updater, daemon=True)
    reminders_thread.start()

    schedule_thread = threading.Thread(target=_schedule_updater, daemon=True)
    schedule_thread.start()

    webview.start()
