@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
    echo Not set up yet - double-click setup.bat first.
    pause
    exit /b 1
)
REM Runs in the background: look for the blue circle icon near the clock.
start "" ".venv\Scripts\pythonw.exe" tray_app.py
