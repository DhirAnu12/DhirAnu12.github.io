@echo off
setlocal
cd /d "%~dp0"
title Assistant setup

echo.
echo  ==========================================
echo    Setting up your personal AI assistant
echo  ==========================================
echo.

REM --- 1. Check Python 3.11+ is installed --------------------------------------
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1
if errorlevel 1 (
    echo  [X] Python 3.11 or newer is required.
    echo      Download it from https://www.python.org/downloads/
    echo      IMPORTANT: tick "Add python.exe to PATH" during installation.
    echo.
    pause
    exit /b 1
)
echo  [OK] Python found.

REM --- 2. Create a private Python environment for this project -----------------
if not exist ".venv\Scripts\python.exe" (
    echo  ... Creating virtual environment ^(one-time^)
    python -m venv .venv || goto :failed
)

REM --- 3. Install the libraries ------------------------------------------------
echo  ... Installing libraries ^(this can take a few minutes the first time^)
".venv\Scripts\python.exe" -m pip install --upgrade pip --quiet || goto :failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt --quiet || goto :failed
echo  [OK] Libraries installed.

REM --- 4. Create the .env file for the API key ---------------------------------
if not exist ".env" (
    copy ".env.example" ".env" >nul
    echo  [OK] Created your .env file.
)

findstr /r /c:"^OPENAI_API_KEY=sk-" ".env" >nul
if errorlevel 1 (
    echo.
    echo  ------------------------------------------------------------
    echo   One last step: add your OpenAI API key.
    echo   Notepad will open your .env file now. Paste your key after
    echo   OPENAI_API_KEY=  then save and close Notepad.
    echo   Get a key at https://platform.openai.com/api-keys
    echo  ------------------------------------------------------------
    echo.
    pause
    notepad ".env"
)

echo.
echo  ==========================================
echo    All done!
echo    - Personalise your assistant in settings.toml
echo    - Then double-click start.bat to run it
echo  ==========================================
echo.
pause
exit /b 0

:failed
echo.
echo  [X] Setup failed. Scroll up to see the error, then try again.
echo.
pause
exit /b 1
