"""
Unit tests for the deterministic scheduling engine (friday/scheduling/*).

Scope: everything that's pure Python — freetime, scoring, engine, replan,
next_action — tested with in-memory Task/CalendarEvent/UserPrefs/ScheduleBlock
objects, no disk storage involved. friday/db/schedule.py (the local JSON
store in data/) and friday/scheduling/service.py are NOT covered here.

Run with: python -m unittest discover tests
"""

import sys
import unittest
from datetime import date, datetime, timedelta

sys.path.insert(0, __file__.rsplit("tests", 1)[0])

from friday.scheduling.engine import generate_daily_schedule
from friday.scheduling.freetime import compute_free_blocks, waking_window
from friday.scheduling.models import CalendarEvent, ScheduleBlock, Task, UserPrefs
from friday.scheduling.next_action import get_recommended_next_action
from friday.scheduling.recurrence import next_occurrence
from friday.scheduling.replan import replan_day
from friday.scheduling.scoring import ScoringContext, score_task, score_tasks
from friday.scheduling.weekly import generate_weekly_plan


DAY = date(2026, 8, 3)
NOW = datetime(2026, 8, 3, 7, 0)


def make_prefs(**overrides) -> UserPrefs:
    prefs = UserPrefs(
        waking_time="07:00",
        sleeping_time="23:00",
        meal_windows=[{"name": "lunch", "start": "12:30", "end": "13:15"}],
        daily_work_capacity_minutes=480,
        max_deep_work_minutes=120,
        min_buffer_minutes=10,
        high_energy_periods=[{"start": "09:00", "end": "12:00"}],
    )
    for k, v in overrides.items():
        setattr(prefs, k, v)
    return prefs


def make_task(id, title, **overrides) -> Task:
    defaults = dict(
        id=id, title=title, priority="medium", energy_required="medium",
        estimated_duration_minutes=60, can_split=False,
    )
    defaults.update(overrides)
    return Task(**defaults)


class TestFreetime(unittest.TestCase):
    def test_removes_meals_and_events(self):
        prefs = make_prefs()
        events = [CalendarEvent(id=1, title="Standup", start_time=datetime(2026, 8, 3, 10, 0),
                                 end_time=datetime(2026, 8, 3, 10, 30))]
        blocks = compute_free_blocks(DAY, events, prefs, now=NOW)
        for b in blocks:
            self.assertFalse(b.start <= datetime(2026, 8, 3, 10, 15) < b.end, "event window should be excluded")
            self.assertFalse(b.start <= datetime(2026, 8, 3, 12, 45) < b.end, "meal window should be excluded")

    def test_event_travel_and_prep_buffers_expand_busy_window(self):
        prefs = make_prefs()
        events = [CalendarEvent(id=1, title="Meeting", start_time=datetime(2026, 8, 3, 14, 0),
                                 end_time=datetime(2026, 8, 3, 15, 0),
                                 travel_buffer_minutes=15, preparation_buffer_minutes=10)]
        blocks = compute_free_blocks(DAY, events, prefs, now=NOW)
        # 13:50 (prep+travel before) and 15:10 (travel after) should both be busy
        for probe in (datetime(2026, 8, 3, 13, 50), datetime(2026, 8, 3, 15, 10)):
            self.assertFalse(any(b.start <= probe < b.end for b in blocks))

    def test_overnight_sleep_window_rolls_to_next_day(self):
        prefs = make_prefs(waking_time="09:00", sleeping_time="00:30")
        wake, sleep = waking_window(DAY, prefs)
        self.assertEqual(sleep.date(), DAY + timedelta(days=1))
        self.assertGreater(sleep, wake)

    def test_now_clips_start_of_today(self):
        prefs = make_prefs()
        later = datetime(2026, 8, 3, 11, 0)
        blocks = compute_free_blocks(DAY, [], prefs, now=later)
        self.assertTrue(all(b.start >= later for b in blocks))

    def test_extra_busy_blocks_locked_time(self):
        prefs = make_prefs()
        extra = [(datetime(2026, 8, 3, 8, 0), datetime(2026, 8, 3, 9, 0))]
        blocks = compute_free_blocks(DAY, [], prefs, now=NOW, extra_busy=extra)
        probe = datetime(2026, 8, 3, 8, 30)
        self.assertFalse(any(b.start <= probe < b.end for b in blocks))


class TestScoring(unittest.TestCase):
    def test_overdue_outscores_future_deadline(self):
        ctx = ScoringContext(now=NOW)
        overdue = make_task(1, "Overdue", deadline=NOW - timedelta(hours=2))
        future = make_task(2, "Future", deadline=NOW + timedelta(days=10))
        self.assertGreater(score_task(overdue, ctx).score, score_task(future, ctx).score)

    def test_priority_ordering(self):
        ctx = ScoringContext(now=NOW)
        critical = make_task(1, "C", priority="critical")
        low = make_task(2, "L", priority="low")
        self.assertGreater(score_task(critical, ctx).score, score_task(low, ctx).score)

    def test_postponed_task_gets_a_bump(self):
        ctx = ScoringContext(now=NOW)
        fresh = make_task(1, "Fresh", postponed_count=0)
        postponed = make_task(2, "Postponed", postponed_count=3)
        # identical otherwise -> postponed should score higher due to the nudge
        self.assertGreater(score_task(postponed, ctx).score, score_task(fresh, ctx).score)

    def test_blocking_count_rewards_unblocking_work(self):
        ctx = ScoringContext(now=NOW, blocking_count={1: 3})
        blocker = make_task(1, "Blocker")
        normal = make_task(2, "Normal")
        self.assertGreater(score_task(blocker, ctx).score, score_task(normal, ctx).score)

    def test_score_tasks_sorts_descending(self):
        ctx = ScoringContext(now=NOW)
        tasks = [make_task(1, "Low", priority="low"), make_task(2, "Critical", priority="critical")]
        scored = score_tasks(tasks, ctx)
        self.assertEqual(scored[0].task.id, 2)


class TestEngine(unittest.TestCase):
    def test_deadline_prioritization(self):
        """Given two equal-effort tasks that can't both fit before their
        respective deadlines, the more urgent one should land first."""
        prefs = make_prefs()
        urgent = make_task(1, "Urgent", deadline=NOW + timedelta(hours=20), estimated_duration_minutes=60)
        chill = make_task(2, "Chill", deadline=NOW + timedelta(days=14), estimated_duration_minutes=60)
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [urgent, chill], [], prefs, ctx)
        urgent_block = next(b for b in result.blocks if b.task_id == 1)
        chill_block = next(b for b in result.blocks if b.task_id == 2)
        self.assertLess(urgent_block.start_time, chill_block.start_time)

    def test_fixed_event_protection(self):
        prefs = make_prefs()
        events = [CalendarEvent(id=1, title="Standup", start_time=datetime(2026, 8, 3, 9, 0),
                                 end_time=datetime(2026, 8, 3, 9, 30))]
        tasks = [make_task(i, f"T{i}", estimated_duration_minutes=30) for i in range(1, 8)]
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, tasks, events, prefs, ctx)
        for b in result.blocks:
            if b.event_id:
                continue
            overlaps = b.start_time < datetime(2026, 8, 3, 9, 30) and b.end_time > datetime(2026, 8, 3, 9, 0)
            self.assertFalse(overlaps, f"task block {b.start_time}-{b.end_time} overlaps the fixed event")

    def test_task_splitting_sums_to_full_duration(self):
        prefs = make_prefs(daily_work_capacity_minutes=600)
        # A single splittable 4-hour task, plus a fixed event that chops the day
        # into two chunks too small individually for the whole task at once.
        events = [CalendarEvent(id=1, title="Long meeting", start_time=datetime(2026, 8, 3, 8, 30),
                                 end_time=datetime(2026, 8, 3, 12, 0))]
        big_task = make_task(1, "Deep work", estimated_duration_minutes=240, can_split=True, minimum_work_block=30)
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [big_task], events, prefs, ctx)
        placed = [b for b in result.blocks if b.task_id == 1]
        self.assertGreater(len(placed), 1, "should have split across multiple blocks")
        self.assertEqual(sum(b.duration_minutes for b in placed), 240)

    def test_non_splittable_task_is_never_split(self):
        prefs = make_prefs()
        task = make_task(1, "Atomic", estimated_duration_minutes=90, can_split=False)
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [task], [], prefs, ctx)
        placed = [b for b in result.blocks if b.task_id == 1]
        self.assertEqual(len(placed), 1)
        self.assertEqual(placed[0].duration_minutes, 90)

    def test_dependency_handling_excludes_blocked_task(self):
        prefs = make_prefs()
        blocker = make_task(1, "Blocker", estimated_duration_minutes=30)
        dependent = make_task(2, "Dependent", estimated_duration_minutes=30, dependencies=[1])
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [blocker, dependent], [], prefs, ctx)
        self.assertIn(dependent, result.unscheduled_tasks)
        self.assertTrue(any("dependency" in d for d in result.decisions))

    def test_dependency_resolves_once_blocker_is_done(self):
        prefs = make_prefs()
        # blocker not passed in at all == already completed, per engine's contract
        dependent = make_task(2, "Dependent", estimated_duration_minutes=30, dependencies=[1])
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [dependent], [], prefs, ctx)
        self.assertNotIn(dependent, result.unscheduled_tasks)

    def test_overloaded_day_leaves_low_priority_unscheduled(self):
        prefs = make_prefs(daily_work_capacity_minutes=120)
        tasks = [
            make_task(1, "Must do", priority="critical", estimated_duration_minutes=90),
            make_task(2, "Nice to have", priority="low", estimated_duration_minutes=90),
            make_task(3, "Also low", priority="low", estimated_duration_minutes=90),
        ]
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, tasks, [], prefs, ctx)
        placed_minutes = sum(b.duration_minutes for b in result.blocks if b.task_id)
        self.assertLessEqual(placed_minutes, 120)
        placed_ids = {b.task_id for b in result.blocks if b.task_id}
        self.assertIn(1, placed_ids, "critical task should be placed")
        self.assertTrue(len(result.unscheduled_tasks) >= 1)

    def test_task_that_cannot_fit_anywhere_stays_unscheduled(self):
        prefs = make_prefs(waking_time="09:00", sleeping_time="10:00")  # tiny 1-hour day
        huge = make_task(1, "Too big", estimated_duration_minutes=300, can_split=False)
        ctx = ScoringContext(now=datetime(2026, 8, 3, 9, 0))
        result = generate_daily_schedule(DAY, [huge], [], prefs, ctx)
        self.assertIn(huge, result.unscheduled_tasks)
        self.assertEqual([b for b in result.blocks if b.task_id == 1], [])

    def test_locked_blocks_are_protected_and_returned(self):
        prefs = make_prefs()
        locked = ScheduleBlock(
            id=99, schedule_date=DAY.isoformat(),
            start_time=datetime(2026, 8, 3, 9, 0), end_time=datetime(2026, 8, 3, 10, 0),
            block_type="task", status="upcoming", task_id=5, locked=True, created_by="user",
            reason="user pinned this",
        )
        other = make_task(6, "Other", estimated_duration_minutes=30)
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [other], [], prefs, ctx, locked_blocks=[locked])
        self.assertIn(locked, result.blocks)
        for b in result.blocks:
            if b.task_id == 6:
                overlaps = b.start_time < locked.end_time and b.end_time > locked.start_time
                self.assertFalse(overlaps)

    def test_overnight_deadline_marks_task_at_risk(self):
        prefs = make_prefs()
        task = make_task(1, "Due after midnight", deadline=datetime(2026, 8, 4, 0, 30), estimated_duration_minutes=600)
        # deliberately unfillable today (too long) so it stays unscheduled and we can check at-risk
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [task], [], prefs, ctx)
        self.assertIn(task, result.at_risk_tasks)


class TestReplan(unittest.TestCase):
    def _base(self):
        prefs = make_prefs()
        t1 = make_task(1, "Calculus", priority="high", estimated_duration_minutes=90,
                        deadline=NOW + timedelta(hours=26))
        t2 = make_task(2, "Internship App", priority="medium", estimated_duration_minutes=60,
                        deadline=NOW + timedelta(days=7))
        ctx = ScoringContext(now=NOW)
        initial = generate_daily_schedule(DAY, [t1, t2], [], prefs, ctx)
        return prefs, [t1, t2], initial

    def test_replan_after_delay_pushes_later_tasks(self):
        prefs, tasks, initial = self._base()
        now = NOW + timedelta(hours=2)  # partway into the day
        # Simulate: first task's block ran over -> mark it active/ongoing (protected)
        blocks = list(initial.blocks)
        blocks[0] = ScheduleBlock(**{**blocks[0].__dict__, "status": "active"})
        tasks[0] = Task(**{**tasks[0].__dict__, "remaining_duration_minutes": 200})  # ran way over

        ctx = ScoringContext(now=now)
        result = replan_day("task_completed_late", DAY, blocks, tasks, [], prefs, ctx,
                             trigger_detail="Calculus took 90 minutes longer than expected.")
        self.assertTrue(len(result.changes) >= 1)
        # the active block should still be present, untouched, in the new plan
        self.assertTrue(any(b.status == "active" and b.task_id == 1 for b in result.blocks))

    def test_locked_block_survives_replan(self):
        prefs, tasks, initial = self._base()
        blocks = list(initial.blocks)
        locked_start = blocks[-1].start_time
        blocks[-1] = ScheduleBlock(**{**blocks[-1].__dict__, "locked": True})

        ctx = ScoringContext(now=NOW)
        new_task = make_task(3, "New urgent thing", priority="critical", estimated_duration_minutes=30,
                              deadline=NOW + timedelta(hours=1))
        result = replan_day("new_task_added", DAY, blocks, tasks + [new_task], [], prefs, ctx,
                             trigger_detail="Added a new urgent task.")
        locked_after = next(b for b in result.blocks if b.locked)
        self.assertEqual(locked_after.start_time, locked_start)

    def test_low_energy_deprioritizes_high_energy_tasks(self):
        prefs = make_prefs()
        high_energy_task = make_task(1, "Hard thing", energy_required="high", estimated_duration_minutes=60)
        easy_task = make_task(2, "Easy thing", energy_required="low", estimated_duration_minutes=60)

        low_ctx = ScoringContext(now=NOW, current_energy="low")
        result_low = generate_daily_schedule(DAY, [high_energy_task, easy_task], [], prefs, low_ctx)
        first_low = min(result_low.blocks, key=lambda b: b.start_time)

        high_ctx = ScoringContext(now=NOW, current_energy="high")
        result_high = generate_daily_schedule(DAY, [high_energy_task, easy_task], [], prefs, high_ctx)
        first_high = min(result_high.blocks, key=lambda b: b.start_time)

        self.assertEqual(first_low.task_id, 2)   # easy task first when energy is low
        self.assertEqual(first_high.task_id, 1)  # hard task first when energy is high


class TestNextAction(unittest.TestCase):
    def test_recommends_active_task(self):
        prefs = make_prefs()
        task = make_task(1, "Now", estimated_duration_minutes=60)
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [task], [], prefs, ctx)
        mid = result.blocks[0].start_time + timedelta(minutes=20)
        action = get_recommended_next_action(mid, result, [task], ScoringContext(now=mid))
        self.assertEqual(action.task.id, 1)
        self.assertTrue(action.start_immediately)
        self.assertLessEqual(action.work_for_minutes, 60)

    def test_recommends_best_fit_in_a_gap(self):
        prefs = make_prefs()
        events = [CalendarEvent(id=1, title="Meeting", start_time=datetime(2026, 8, 3, 8, 0),
                                 end_time=datetime(2026, 8, 3, 20, 0))]
        task = make_task(1, "Only option", estimated_duration_minutes=30)
        ctx = ScoringContext(now=NOW)
        schedule = generate_daily_schedule(DAY, [task], events, prefs, ctx)
        action = get_recommended_next_action(NOW, schedule, [task], ctx)
        self.assertEqual(action.task.id, 1)
        self.assertTrue(action.start_immediately)


class TestEdgeCases(unittest.TestCase):
    """Regression tests for bugs found during stress-testing."""

    def test_zero_duration_task_not_coerced_to_thirty(self):
        """Task.duration_minutes used to do `estimated_duration_minutes or 30`,
        which silently turned an explicit 0 into 30 (falsy-zero bug)."""
        task = make_task(1, "Instant", estimated_duration_minutes=0)
        self.assertEqual(task.duration_minutes, 0)

    def test_negative_duration_never_produces_negative_blocks(self):
        prefs = make_prefs()
        task = make_task(1, "Bad input", estimated_duration_minutes=-30)
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [task], [], prefs, ctx)
        for b in result.blocks:
            self.assertGreaterEqual(b.duration_minutes, 0)

    def test_split_chunk_never_smaller_than_minimum_work_block(self):
        """max_deep_work_minutes smaller than minimum_work_block used to be
        able to produce undersized chunks."""
        prefs = make_prefs(max_deep_work_minutes=5)
        task = make_task(1, "Splittable", estimated_duration_minutes=100, can_split=True, minimum_work_block=25)
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [task], [], prefs, ctx)
        placed = [b for b in result.blocks if b.task_id == 1]
        self.assertTrue(placed)
        for b in placed:
            self.assertGreaterEqual(b.duration_minutes, 25)

    def test_self_dependency_does_not_crash(self):
        prefs = make_prefs()
        task = make_task(1, "SelfDep", dependencies=[1])
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [task], [], prefs, ctx)
        self.assertIn(task, result.unscheduled_tasks)

    def test_circular_dependency_does_not_crash(self):
        prefs = make_prefs()
        a = make_task(1, "A", dependencies=[2])
        b = make_task(2, "B", dependencies=[1])
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [a, b], [], prefs, ctx)
        self.assertIn(a, result.unscheduled_tasks)
        self.assertIn(b, result.unscheduled_tasks)

    def test_overlapping_fixed_events_do_not_crash(self):
        prefs = make_prefs()
        events = [
            CalendarEvent(id=1, title="A", start_time=datetime(2026, 8, 3, 10, 0), end_time=datetime(2026, 8, 3, 11, 0)),
            CalendarEvent(id=2, title="B", start_time=datetime(2026, 8, 3, 10, 30), end_time=datetime(2026, 8, 3, 11, 30)),
        ]
        ctx = ScoringContext(now=NOW)
        result = generate_daily_schedule(DAY, [], events, prefs, ctx)
        self.assertEqual(len(result.blocks), 2)

    def test_large_task_count_stays_fast(self):
        import time
        prefs = make_prefs(daily_work_capacity_minutes=600)
        tasks = [make_task(i, f"T{i}", estimated_duration_minutes=15) for i in range(1, 301)]
        ctx = ScoringContext(now=NOW)
        start = time.time()
        generate_daily_schedule(DAY, tasks, [], prefs, ctx)
        self.assertLess(time.time() - start, 5)


class TestRecurrence(unittest.TestCase):
    def test_daily(self):
        base = datetime(2026, 8, 3, 9, 0)
        self.assertEqual(next_occurrence("daily", base), base + timedelta(days=1))

    def test_weekly(self):
        base = datetime(2026, 8, 3, 9, 0)
        self.assertEqual(next_occurrence("weekly", base), base + timedelta(days=7))

    def test_weekdays_skips_weekend(self):
        friday = datetime(2026, 8, 7, 9, 0)  # a Friday
        nxt = next_occurrence("weekdays", friday)
        self.assertEqual(nxt.weekday(), 0)  # Monday
        self.assertEqual(nxt, datetime(2026, 8, 10, 9, 0))

    def test_every_n_days(self):
        base = datetime(2026, 8, 3, 9, 0)
        self.assertEqual(next_occurrence("every_3_days", base), base + timedelta(days=3))

    def test_unknown_rule_returns_none(self):
        self.assertIsNone(next_occurrence("monthly-ish", datetime(2026, 8, 3)))
        self.assertIsNone(next_occurrence(None, datetime(2026, 8, 3)))
        self.assertIsNone(next_occurrence("", datetime(2026, 8, 3)))


class TestWeeklyPlan(unittest.TestCase):
    WEEK_START = date(2026, 8, 3)  # a Monday

    def test_deadline_bound_task_lands_on_or_before_its_deadline_day(self):
        prefs = make_prefs(daily_work_capacity_minutes=480, available_days=["mon", "tue", "wed", "thu", "fri", "sat", "sun"])
        task = make_task(1, "Report", estimated_duration_minutes=60,
                          deadline=datetime(2026, 8, 5, 17, 0))  # Wednesday
        result = generate_weekly_plan(self.WEEK_START, [task], [], [], prefs)
        assigned_day = next(k for k, ids in result.day_assignments.items() if 1 in ids)
        deadline_offset = (date(2026, 8, 5) - self.WEEK_START).days
        assigned_offset = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"].index(assigned_day)
        self.assertLessEqual(assigned_offset, deadline_offset)

    def test_overloaded_day_detected(self):
        prefs = make_prefs(daily_work_capacity_minutes=60, available_days=["mon"])
        tasks = [make_task(i, f"T{i}", estimated_duration_minutes=60,
                            deadline=datetime(2026, 8, 3, 23, 0)) for i in range(1, 4)]
        result = generate_weekly_plan(self.WEEK_START, tasks, [], [], prefs)
        self.assertIn("mon", result.overloaded_days)

    def test_unavailable_day_gets_zero_capacity(self):
        prefs = make_prefs(daily_work_capacity_minutes=480, available_days=["mon", "tue", "wed", "thu", "fri"])
        # A task with no deadline should never land on sat/sun if they're unavailable
        task = make_task(1, "Whenever", estimated_duration_minutes=30)
        result = generate_weekly_plan(self.WEEK_START, [task] * 1, [], [], prefs)
        self.assertNotIn(1, result.day_assignments.get("sat", []))
        self.assertNotIn(1, result.day_assignments.get("sun", []))

    def test_task_that_cannot_fit_the_week_goes_to_backlog(self):
        prefs = make_prefs(daily_work_capacity_minutes=30, available_days=["mon"])
        task = make_task(1, "Too big for the week", estimated_duration_minutes=999)
        result = generate_weekly_plan(self.WEEK_START, [task], [], [], prefs)
        self.assertIn(task, result.unassigned_backlog)

    def test_recurring_tasks_excluded_from_day_assignment(self):
        prefs = make_prefs()
        habit = make_task(1, "Habit", is_recurring=True, recurrence_rule="daily", estimated_duration_minutes=15)
        result = generate_weekly_plan(self.WEEK_START, [habit], [], [], prefs)
        all_assigned = {tid for ids in result.day_assignments.values() for tid in ids}
        self.assertNotIn(1, all_assigned)

    def test_workload_by_category_sums_across_week(self):
        prefs = make_prefs()
        tasks = [
            make_task(1, "A", category="work", estimated_duration_minutes=60),
            make_task(2, "B", category="work", estimated_duration_minutes=30),
            make_task(3, "C", category="personal", estimated_duration_minutes=45),
        ]
        result = generate_weekly_plan(self.WEEK_START, tasks, [], [], prefs)
        self.assertEqual(result.workload_by_category["work"], 90)
        self.assertEqual(result.workload_by_category["personal"], 45)

    def test_events_reduce_day_capacity(self):
        prefs = make_prefs(daily_work_capacity_minutes=480)
        events = [CalendarEvent(id=1, title="All-day-ish", start_time=datetime(2026, 8, 3, 9, 0),
                                 end_time=datetime(2026, 8, 3, 17, 0))]  # 480 min on Monday
        task = make_task(1, "Anything", estimated_duration_minutes=30)
        result = generate_weekly_plan(self.WEEK_START, [task], events, [], prefs)
        self.assertNotIn(1, result.day_assignments.get("mon", []))

    def test_outcomes_pass_through(self):
        prefs = make_prefs()
        result = generate_weekly_plan(self.WEEK_START, [], [], ["Ship the demo", "Study for exam"], prefs)
        self.assertEqual(result.outcomes, ["Ship the demo", "Study for exam"])


if __name__ == "__main__":
    unittest.main()
