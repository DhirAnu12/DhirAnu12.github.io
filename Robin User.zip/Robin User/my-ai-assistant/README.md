# Your Own AI Assistant (Tony Stark style)

> *"Jarvis, good morning."*

A voice assistant that runs on your own Windows PC. Say its name, then ask it to do
things: set reminders, plan your day, read you the news, open your apps and
websites, summarise the article you're reading, or write up a recipe or how-to.

You choose its **name, voice, personality, and how it talks to you**. Everything is
in one settings file.

- ✅ Runs locally on your computer. Your reminders and schedule are saved in the `data/` folder.
- ✅ You only need **one** key: an OpenAI API key.
- ✅ No accounts, databases, or cloud servers to set up.

---

## What you need

| | |
| --- | --- |
| **Windows 10 or 11** | Some features (notifications, Notepad, Chrome control) are Windows-only. |
| **Python 3.11 or newer** | Download from [python.org/downloads](https://www.python.org/downloads/). During install, **tick "Add python.exe to PATH"**. |
| **An OpenAI API key** | Create one at [platform.openai.com/api-keys](https://platform.openai.com/api-keys). It's pay-as-you-go and usually cheap, but a noisy room costs more because any speech the mic hears gets transcribed (see *Your data and privacy*). |
| **A microphone and speakers** | Any headset or built-in laptop mic works. |

---

## Setup (about 5 minutes)

### 1. Install
Double-click **`setup.bat`**.

It checks Python, installs everything the assistant needs, and opens Notepad so you
can paste your OpenAI key.

> **Adding the key by hand:** make a copy of `.env.example`, rename the copy to `.env`,
> and paste your key after `OPENAI_API_KEY=` with no spaces or quotes:
> ```
> OPENAI_API_KEY=sk-your-key-here
> ```

### 2. Make it yours
Open **`settings.toml`** in Notepad. Each setting has a comment explaining it.
The main ones:

```toml
[assistant]
name = "Jarvis"          # also the wake word you say out loud
user_title = "sir"       # "ma'am", "boss", your name, or "" for nothing
personality = """
You are calm, composed, and sharp. Speak like a trusted aide, with a touch of dry wit.
"""

[voice]
tts_voice = "echo"       # alloy, ash, coral, echo, fable, nova, onyx, sage, shimmer

[workspace]
apps = ["chrome", "code", "explorer %USERPROFILE%\\Downloads"]
```

Save the file. Your changes apply the next time you start the assistant.

### 3. Run it
Double-click **`start.bat`**.

Two windows appear: a small minimised **tool server** and the **assistant**.
When you see `Jarvis is online`, say:

> **"Jarvis, what's on today?"**

To stop it, close both windows (or press `Ctrl+C` in the assistant window).

> **Prefer a tray icon?** Double-click `start_tray.bat`. A blue circle appears near
> the clock. Right-click it to **Start**, **Stop**, or **Quit**.

---

## Things to try

| Say… | What happens |
| --- | --- |
| "**Jarvis**, good morning" | Today's reminders, a quick market update, an offer of a full news brief, and your workspace apps open |
| "Remind me to call mum in 30 minutes" | Sets a reminder. You get a pop-up and a spoken reminder when it's due |
| "What are my reminders?" | Lists upcoming reminders |
| "Add a task to finish the report, high priority, about an hour" | Adds a task to your planner |
| "Plan my day" | Builds today's schedule around your tasks, meals, and breaks |
| "What should I do next?" | Picks the best task to do right now |
| "I'm tired" / "I've got loads of energy" | Lightens or front-loads the rest of the day |
| "I finished early" / "This is taking longer" | Re-plans the rest of your day |
| "What's going on in the world?" | Reads the top world headlines |
| "Open YouTube and Gmail" | Opens those sites in Chrome |
| "Summarise this article" *(with Chrome open)* | Reads the page you're on, opens a full summary in Notepad, and tells you the gist |
| "Give me a recipe for lasagne" | Writes the full recipe into Notepad and tells you the short version |
| "Open my workspace" | Opens every app listed under `[workspace]` in `settings.toml` |

After you've spoken once, the assistant keeps listening for follow-up questions for
90 seconds without the wake word. You can change this with `follow_up_seconds`.

**Mute / unmute the mic:** `Ctrl+Shift+M` (change it under `[hotkeys]`).

---

## The on-screen HUD

While the assistant runs, a transparent full-screen overlay shows the time, today's
reminders, your current schedule block, and buttons to **Start / Complete / Skip /
Replan** tasks. The centre ring pulses when the assistant speaks.

- Doesn't fit your screen? Set `width` and `height` under `[hud]` to your resolution.
- Don't want it? Set `enabled = false` under `[hud]`.

---

## Troubleshooting

| Problem | Fix |
| --- | --- |
| `Python 3.11 or newer is required` | Install Python from python.org and tick **"Add python.exe to PATH"**. Then run `setup.bat` again. |
| `No OpenAI API key found` | Open `.env` and check the line reads `OPENAI_API_KEY=sk-...` with no spaces or quotes. |
| It never wakes up | Say the name clearly at the start of a sentence. If your mic is quiet, **lower** `silence_threshold` in `settings.toml` (try `300`). |
| It wakes up on background noise | **Raise** `silence_threshold` (try `800`). |
| It keeps mishearing the name | Pick a name that's easy to recognise and isn't a common word. Two syllables, like *Jarvis*, *Nova*, or *Atlas*, work well. |
| It cuts me off mid-sentence | Raise `silence_duration` (try `1.2`). |
| `Could not reach the tool server` | Start with `start.bat`, which runs both parts. If you run things by hand, start `server.py` **before** `assistant.py`. |
| Hotkeys don't work | Some apps block global hotkeys unless the assistant runs as administrator. Right-click `start.bat` → *Run as administrator*. |
| `There's a typo in settings.toml` | Text values need straight quotes (`"like this"`) and lists need square brackets. The error message says which line is wrong. |
| Errors mentioning "quota" or "billing" | Add credit to your OpenAI account at [platform.openai.com/settings/organization/billing](https://platform.openai.com/settings/organization/billing). |

---

## Your data and privacy

- **Reminders, tasks, and your schedule** are stored as plain JSON files in `data/`.
  To start fresh, delete the files in that folder.
- **Your voice and messages** are sent to OpenAI to transcribe them, generate a reply,
  and speak it. Wake-word detection works the same way: whenever the mic hears
  speech, that clip is sent to OpenAI to check whether you said the name. If you
  want privacy, mute with `Ctrl+Shift+M` or close the assistant. Nothing else is
  uploaded anywhere.
- **Your `.env` file holds your API key.** Treat it like a password: don't share it,
  and don't upload it. It's already excluded in `.gitignore` if you use Git.

---

## For tinkerers

### How it fits together

```text
 Microphone ─► Speech-to-text (OpenAI)
                     │
                     ▼
               GPT model  ◄────────►  Tool server (server.py, MCP over SSE on :8000)
                     │                  ├─ reminders, planner, news, websites
                     ▼                  └─ apps, page summaries, documents …
          Text-to-speech (OpenAI) ─► Speakers          data/  ← saved locally
```

| File / folder | What it is |
| --- | --- |
| `settings.toml` | **Your personal settings.** Start here. |
| `.env` | Your secret API key (you create this from `.env.example`). |
| `assistant.py` | The voice loop: wake word → listen → think → speak, plus reminder alerts. |
| `server.py` | The tool server. It exposes every tool to the AI using [MCP](https://modelcontextprotocol.io). |
| `hud_web.py`, `hud_display.html` | The on-screen overlay. |
| `tray_app.py` | The optional system-tray launcher. |
| `friday/tools/` | Each file is a group of tools the AI can call. |
| `friday/scheduling/` | The day-planner engine (pure Python, unit-tested). |
| `friday/db/` | Saves reminders and schedule data to `data/` as JSON. |
| `data/` | Your saved reminders, tasks, and schedule. |

### Add your own tool

1. Create a file in `friday/tools/`, for example `friday/tools/weather.py`:
   ```python
   def register(mcp):
       @mcp.tool()
       def get_weather(city: str) -> str:
           """Gets the current weather for a city."""   # the AI reads this description
           return f"It's sunny in {city}."
   ```
2. Register it in `friday/tools/__init__.py`: add `weather` to the import line and call
   `weather.register(mcp)`.
3. Restart. The assistant sees the new tool automatically and uses it when it fits
   what you asked.

### Run the parts by hand

```bat
.venv\Scripts\python.exe server.py      :: window 1, start this first
.venv\Scripts\python.exe assistant.py   :: window 2
```

### Run the tests

```bat
.venv\Scripts\python.exe -m unittest discover tests
```

---

## Credits

Based on the open-source **F.R.I.D.A.Y. Tony Stark demo**. This edition is local-only
and needs a single key.

## License

MIT
