"""
Optional system-tray launcher — a small icon near the clock with Start / Stop / Quit.
Run with: .venv\Scripts\pythonw.exe tray_app.py   (or double-click start_tray.bat)
"""

import subprocess
import sys
from pathlib import Path

import pystray
from PIL import Image, ImageDraw

from friday.settings import ASSISTANT_NAME

HERE = Path(__file__).resolve().parent
PYTHON = sys.executable
processes = {}

def make_icon():
    img = Image.new('RGB', (64, 64), color=(30, 30, 30))
    d = ImageDraw.Draw(img)
    d.ellipse((16, 16, 48, 48), fill=(0, 200, 255))
    return img

def start_assistant(icon, item):
    if "server" not in processes:
        processes["server"] = subprocess.Popen([PYTHON, "server.py"], cwd=HERE)
    if "voice" not in processes:
        processes["voice"] = subprocess.Popen([PYTHON, "assistant.py"], cwd=HERE)
    icon.notify(f"{ASSISTANT_NAME} started")

def stop_assistant(icon, item):
    for name, proc in list(processes.items()):
        proc.terminate()
    processes.clear()
    icon.notify(f"{ASSISTANT_NAME} stopped")

def quit_app(icon, item):
    stop_assistant(icon, item)
    icon.stop()

icon = pystray.Icon(
    ASSISTANT_NAME,
    make_icon(),
    f"{ASSISTANT_NAME} Assistant",
    menu=pystray.Menu(
        pystray.MenuItem("Start", start_assistant),
        pystray.MenuItem("Stop", stop_assistant),
        pystray.MenuItem("Quit", quit_app),
    ),
)

icon.run()
