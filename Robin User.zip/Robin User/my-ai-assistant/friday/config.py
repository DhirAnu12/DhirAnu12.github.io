"""
Configuration — load environment variables and app-wide settings.
Personal settings (name, voice, workspace apps...) live in settings.toml.
"""

import os
from dotenv import load_dotenv

from friday.settings import ASSISTANT_NAME

load_dotenv()


class Config:
    # Server identity
    SERVER_NAME: str = ASSISTANT_NAME
    DEBUG: bool = os.getenv("DEBUG", "false").lower() == "true"

    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")


config = Config()
