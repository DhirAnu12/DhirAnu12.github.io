"""
Web tools — search, fetch pages, and global news briefings.
"""

import os
import httpx
import shutil
import subprocess
import xml.etree.ElementTree as ET
import asyncio  # Required for parallel execution
import re
from datetime import datetime

URL_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.-]*://")

# Plain "chrome" often isn't on PATH even when Chrome is installed (no App
# Execution Alias registered) — fall back to the usual install locations.
_CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
]


def _chrome_path() -> str:
    found = shutil.which("chrome")
    if found:
        return found
    for path in _CHROME_CANDIDATES:
        if os.path.exists(path):
            return path
    return "chrome"  # last resort — matches the old (broken) behavior


def _normalize_url(url: str) -> str:
    """Adds a scheme if the caller passed a bare domain (e.g. "youtube.com")."""
    url = url.strip()
    return url if URL_SCHEME_RE.match(url) else f"https://{url}"


def _open_in_chrome(urls: list[str]) -> int:
    """Launches Chrome with the given URLs as new tabs. Returns how many opened."""
    clean_urls = [_normalize_url(u) for u in urls if u][:5]
    if not clean_urls:
        return 0
    subprocess.Popen([_chrome_path()] + clean_urls, shell=True)
    return len(clean_urls)

SEED_FEEDS = [
    'https://feeds.bbci.co.uk/news/world/rss.xml',
    'https://www.cnbc.com/id/100727362/device/rss/rss.html',
    'https://rss.nytimes.com/services/xml/rss/nyt/World.xml',
    'https://www.aljazeera.com/xml/rss/all.xml'
]

FINANCE_SEED_FEEDS = [
    'https://www.cnbc.com/id/10000664/device/rss/rss.html',       # CNBC Finance
    'https://feeds.bloomberg.com/markets/news.rss',                # Bloomberg Markets
    'https://www.reutersagency.com/feed/?taxonomy=best-sectors&post_type=best',  # Reuters
    'https://feeds.marketwatch.com/marketwatch/topstories/',       # MarketWatch
    'https://rss.nytimes.com/services/xml/rss/nyt/Business.xml',  # NYT Business
]

async def fetch_and_parse_feed(client, url):
    """Helper function to handle a single feed request and parse its XML."""
    try:
        response = await client.get(url, headers={'User-Agent': 'Friday-AI/1.0'}, timeout=5.0)
        if response.status_code != 200:
            return []

        root = ET.fromstring(response.content)
        # Extract source name from URL (e.g., 'BBC' or 'NYTIMES')
        source_name = url.split('.')[1].upper()
        
        feed_items = []
        # Get top 5 items per feed
        items = root.findall(".//item")[:5]
        for item in items:
            title = item.findtext("title")
            description = item.findtext("description")
            link = item.findtext("link")
            
            if description:
                description = re.sub('<[^<]+?>', '', description).strip()

            feed_items.append({
                "source": source_name,
                "title": title,
                "summary": description[:200] + "..." if description else "",
                "link": link
            })
        return feed_items
    except Exception:
        # If one feed fails, return an empty list so others can still succeed
        return []

def register(mcp):

    @mcp.tool()
    async def get_world_news() -> str:
        """
        Fetches the latest global headlines from major news outlets simultaneously.
        Use this when the user asks 'What's going on in the world?' or for recent events.
        """
        
        async with httpx.AsyncClient(follow_redirects=True, timeout=10) as client:
            # 1. Create a list of 'tasks' (one for each URL)
            tasks = [fetch_and_parse_feed(client, url) for url in SEED_FEEDS]
            
            # 2. Fire them all at once and wait for the results
            # results will be a list of lists: [[news from bbc], [news from nyt], ...]
            results_of_lists = await asyncio.gather(*tasks)
            
            # 3. Flatten the list of lists into a single list of articles
            all_articles = [item for sublist in results_of_lists for item in sublist]

        if not all_articles:
            return "The global news grid is unresponsive. I'm unable to pull headlines."

        # 4. Format the final briefing
        report = ["### GLOBAL NEWS BRIEFING (LIVE)\n"]
        # Limit to top 12 items so the AI doesn't get overwhelmed
        for entry in all_articles[:12]:
            report.append(f"**[{entry['source']}]** {entry['title']}")
            report.append(f"{entry['summary']}")
            report.append(f"Link: {entry['link']}\n")

        return "\n".join(report)

    @mcp.tool()
    async def get_world_finance_news() -> str:
        """
        Fetches the latest finance and market headlines from major financial outlets simultaneously.
        Use this when the user asks about finance news, market updates, or economic developments.
        """

        async with httpx.AsyncClient(follow_redirects=True, timeout=10) as client:
            tasks = [fetch_and_parse_feed(client, url) for url in FINANCE_SEED_FEEDS]
            results_of_lists = await asyncio.gather(*tasks)
            all_articles = [item for sublist in results_of_lists for item in sublist]

        if not all_articles:
            return "The financial feeds are unresponsive right now. I can't pull market headlines."

        report = ["### FINANCE BRIEFING (LIVE)\n"]
        for entry in all_articles[:12]:
            report.append(f"**[{entry['source']}]** {entry['title']}")
            report.append(f"{entry['summary']}")
            report.append(f"Link: {entry['link']}\n")

        return "\n".join(report)

    @mcp.tool()
    async def fetch_url(url: str) -> str:
        """Fetch the raw text content of a URL."""
        async with httpx.AsyncClient(follow_redirects=True, timeout=10) as client:
            response = await client.get(url)
            response.raise_for_status()
            return response.text[:4000]
    
    @mcp.tool()
    async def open_world_monitor() -> str:
        """
        Opens the World Monitor dashboard (worldmonitor.app) in the system's web browser.
        Use this when the user wants a visual overview of global events or a real-time map.
        """
        import webbrowser
        url = "https://worldmonitor.app/"
        
        try:
            webbrowser.open(url)
            return "Displaying the World Monitor on your primary screen now."
        except Exception as e:
            return f"I'm unable to initialize the visual monitor: {str(e)}"

    @mcp.tool()
    async def open_finance_world_monitor() -> str:
        """
        Opens the Finance World Monitor dashboard (finance.worldmonitor.app) in the system's web browser.
        Use this when the user wants a visual overview of global financial markets and trends.
        """
        import webbrowser
        url = "https://finance.worldmonitor.app/"

        try:
            webbrowser.open(url)
            return "Displaying the Finance World Monitor on your primary screen now."
        except Exception as e:
            return f"I'm unable to initialize the finance monitor: {str(e)}"

    @mcp.tool()
    async def open_news_articles(urls: list[str]) -> str:
        """
        Opens a handful of article links as new tabs in Chrome. Use this during a
        full news brief: after calling get_world_news and/or get_world_finance_news,
        pick 3-4 of the most relevant/varied article URLs straight from those tools'
        "Link:" lines and pass them here — don't invent URLs. Capped at 5 tabs.
        """
        try:
            opened = _open_in_chrome(urls)
            if not opened:
                return "No article links to open."
            return f"Opened {opened} article{'s' if opened != 1 else ''} in Chrome."
        except Exception as e:
            return f"Couldn't open those articles: {e}"

    @mcp.tool()
    async def open_website(url_or_urls: list[str]) -> str:
        """
        Opens one or more specific websites in Chrome, e.g. "open YouTube", "pull
        up my email", "go to reddit.com", "open Gmail and my calendar". Pass fully-
        qualified URLs — if the user names a well-known site (YouTube, Gmail,
        Reddit, GitHub, etc.) construct its real URL yourself (e.g.
        "https://youtube.com") before calling this; don't pass bare site names.
        For pulling up several news articles at once after a briefing, use
        open_news_articles instead. Capped at 5 tabs.
        """
        try:
            opened = _open_in_chrome(url_or_urls)
            if not opened:
                return "No website to open."
            return f"Opened {opened} site{'s' if opened != 1 else ''} in Chrome."
        except Exception as e:
            return f"Couldn't open that: {e}"