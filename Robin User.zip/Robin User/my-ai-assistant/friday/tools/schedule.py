"""
Scheduling tools (MCP) — thin wrappers around friday/scheduling/nl_commands.py,
which does the actual work against friday/scheduling/service.py. Mirrors
friday/tools/reminders.py's shape; kept thin on purpose so all the real
scheduling logic lives in one place.
"""

from friday.scheduling import nl_commands as nl


def register(mcp):
    @mcp.tool()
    def plan_my_day(current_energy: str = "medium") -> str:
        """
        Generates (or regenerates) today's schedule from your tasks, deadlines,
        and fixed calendar events. Use this for "plan my day", "what's my
        schedule today", "generate my schedule". current_energy: low, medium,
        or high — infer from context if the user mentioned how they're feeling.
        """
        return nl.plan_my_day(current_energy)

    @mcp.tool()
    def what_should_i_do_next() -> str:
        """
        Recommends the single best next task to work on right now, with how
        long to spend on it. Use for "what should I do next", "what now",
        "what's next on my plate".
        """
        return nl.what_should_i_do_next()

    @mcp.tool()
    def i_finished_task_early(actual_minutes: int = 0, task_title: str = "") -> str:
        """
        Marks the current (or named) task/block complete and replans the rest
        of the day around the freed-up time. Use for "I finished this early",
        "I'm done with this", "that's done". Pass actual_minutes if the user
        mentioned how long it actually took; leave task_title blank to mean
        "whatever I'm currently working on".
        """
        return nl.i_finished_early(actual_minutes if actual_minutes else None, task_title)

    @mcp.tool()
    def task_took_longer(extra_minutes: int, task_title: str = "") -> str:
        """
        Extends the current (or named) task by extra_minutes and replans the
        rest of the day around the overrun. Use for "this is taking longer
        than expected", "I need another 30 minutes", "this took an hour
        longer". Leave task_title blank to mean the current task.
        """
        return nl.this_took_longer(extra_minutes, task_title)

    @mcp.tool()
    def skip_current_task(disposition: str = "backlog", task_title: str = "") -> str:
        """
        Skips the current (or named) task. disposition must be one of:
        'later_today' (stays eligible for later today), 'tomorrow' (moved to
        tomorrow), 'backlog' (unscheduled, no specific day), or 'cancel'
        (removed entirely). Use for "skip this", "I'm not doing this right
        now", "cancel this task".
        """
        return nl.skip_this_task(disposition, task_title)

    @mcp.tool()
    def move_task_to_tomorrow(task_title: str) -> str:
        """
        Moves a specific task off today's schedule and onto tomorrow. Use for
        "move [task] to tomorrow", "add this to tomorrow" when referring to an
        already-existing task.
        """
        return nl.move_task_to_tomorrow(task_title)

    @mcp.tool()
    def report_low_energy() -> str:
        """
        Tells the assistant you're low on energy right now — it lightens the rest of
        today's plan accordingly. Use for "I'm tired", "I'm exhausted", "I
        don't have much energy right now".
        """
        return nl.report_low_energy()

    @mcp.tool()
    def report_high_energy() -> str:
        """
        Tells the assistant you're feeling sharp/energetic right now — it front-loads
        harder work. Use for "I've got a ton of energy", "I'm feeling great,
        let's do the hard stuff".
        """
        return nl.report_high_energy()

    @mcp.tool()
    def report_free_time(minutes: int) -> str:
        """
        Tells the assistant you unexpectedly have free time right now and asks what to
        do with it. Use for "I have two free hours" (pass minutes=120), "I've
        got 30 minutes free".
        """
        return nl.report_free_time(minutes)

    @mcp.tool()
    def what_can_safely_wait() -> str:
        """
        Lists lower-priority tasks that can safely be deferred without risking
        a deadline. Use for "what can wait", "what's not urgent".
        """
        return nl.what_can_safely_wait()

    @mcp.tool()
    def what_deadlines_are_at_risk() -> str:
        """
        Lists tasks whose deadlines are at risk given the current plan. Use for
        "what deadlines are at risk", "am I going to miss anything".
        """
        return nl.what_deadlines_are_at_risk()

    @mcp.tool()
    def replan_rest_of_day(detail: str = "") -> str:
        """
        Manually triggers a replan of everything remaining today, keeping
        completed/active/locked blocks untouched. Use for "replan my day",
        "redo the rest of today", "recalculate my schedule". Pass a short
        `detail` sentence if the user explained why (e.g. what changed).
        """
        return nl.replan_rest_of_day(detail or "Replanning the rest of the day.")

    @mcp.tool()
    def add_scheduling_task(
        title: str,
        description: str = "",
        priority: str = "medium",
        deadline_datetime: str = "",
        estimated_duration_minutes: int = 30,
        category: str = "",
        energy_required: str = "medium",
        can_split: bool = False,
        for_tomorrow: bool = False,
    ) -> str:
        """
        Adds a task to the scheduling system (separate from set_reminder —
        this is real schedulable work with duration/priority/energy, not a
        one-off alert). deadline_datetime, if any, must be "YYYY-MM-DD HH:MM"
        (24-hour), same convention as set_reminder. priority: critical, high,
        medium, or low. energy_required: high, medium, or low. Set
        for_tomorrow=True when the user says "add this to tomorrow" without a
        hard deadline. Use for "add a task to...", "I need to...", "put ... on
        my schedule".
        """
        return nl.add_task(
            title, description, priority,
            deadline_datetime or None, estimated_duration_minutes,
            category or None, energy_required, can_split, for_tomorrow,
        )
