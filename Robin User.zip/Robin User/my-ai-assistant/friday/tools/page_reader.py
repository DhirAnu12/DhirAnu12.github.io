"""
Page reading — grabs the URL from Chrome's address bar (whatever tab the user is
actually looking at), fetches that page, and has GPT-4o read it. Mirrors
tasks.py's create_task_document pattern: full write-up goes to a text file opened
in Notepad, short spoken summary comes back as the tool result.

Note: this only sees server-rendered HTML (via a plain HTTP fetch), not anything
built client-side by JavaScript — works well for articles/blogs/news, less well
for heavily JS-rendered single-page apps.
"""

import ctypes
import os
import re
import subprocess
import tempfile
import time
import tkinter as tk
from datetime import datetime

import httpx
import keyboard
import psutil
from openai import OpenAI
from dotenv import load_dotenv

from friday.settings import ASSISTANT_NAME, settings

load_dotenv()

_client = None


def _openai() -> OpenAI:
    """Created on first use, so the server still starts if the key is missing."""
    global _client
    if _client is None:
        _client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    return _client


def _foreground_process_name() -> str:
    hwnd = ctypes.windll.user32.GetForegroundWindow()
    pid = ctypes.c_ulong()
    ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    try:
        return psutil.Process(pid.value).name().lower()
    except Exception:
        return ""


def _get_current_chrome_url() -> str:
    """Reads the URL out of Chrome's address bar via Ctrl+L/Ctrl+C. Only sends
    those keystrokes if Chrome is actually the foreground window — otherwise we'd
    be blindly firing a hotkey into whatever app the user happens to have
    focused, which could do something unrelated (and wrong) there instead."""
    if _foreground_process_name() != "chrome.exe":
        raise RuntimeError(
            "Chrome isn't the active window right now — switch to the page you "
            "want summarized first"
        )

    keyboard.send("ctrl+l")
    time.sleep(0.15)
    keyboard.send("ctrl+c")
    time.sleep(0.2)
    keyboard.send("esc")  # deselect the address bar, hand focus back to the page

    root = tk.Tk()
    root.withdraw()
    try:
        url = root.clipboard_get().strip()
    except Exception:
        url = ""
    finally:
        root.destroy()

    if not url.startswith(("http://", "https://")):
        raise RuntimeError("couldn't read a URL from the address bar")
    return url


def _html_to_text(html: str, max_chars: int = 20000) -> str:
    html = re.sub(r"<script.*?</script>", " ", html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r"<style.*?</style>", " ", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", html)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:max_chars]


def _fetch_page_text(url: str) -> str:
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) PersonalAssistant/1.0"}
    with httpx.Client(follow_redirects=True, timeout=10, headers=headers) as client:
        response = client.get(url)
        response.raise_for_status()
        return _html_to_text(response.text)


def register(mcp):
    @mcp.tool()
    def summarize_current_page(topic: str = "") -> str:
        """
        Reads whatever page is open in the user's current Chrome tab (grabs the
        URL from the address bar, fetches and reads the page), writes a full
        detailed summary to a text file and opens it in Notepad, and returns a
        short 1-2 sentence spoken summary. Use this when the user says things
        like "summarize this", "summarize this article", "what does this page
        say". Requires Chrome to be the active window. Optional `topic`: any
        extra context the user mentioned — leave blank if they didn't say
        anything specific.
        """
        try:
            url = _get_current_chrome_url()
        except Exception as e:
            return str(e)

        try:
            page_text = _fetch_page_text(url)
        except Exception as e:
            return f"I got the page ({url}) but couldn't fetch it: {e}"

        if not page_text:
            return f"That page ({url}) didn't have any readable text content to summarize."

        try:
            summary_context = f" The user said this is about: {topic}." if topic else ""
            full_prompt = f"""Read the following page content and write a complete, detailed
summary covering the key points, arguments, and any important specifics (numbers,
names, conclusions). Format it clearly with headers where appropriate. This was
fetched from {url}.{summary_context}

PAGE CONTENT:
{page_text}"""

            completion = _openai().chat.completions.create(
                model=settings["models"]["documents"],
                messages=[{"role": "user", "content": full_prompt}],
            )
            full_content = completion.choices[0].message.content

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_topic = "".join(c if c.isalnum() or c in " -_" else "" for c in (topic or "page_summary"))[:50]
            filepath = os.path.join(tempfile.gettempdir(), f"{ASSISTANT_NAME}_{safe_topic}_{timestamp}.txt")
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(f"{url}\n{'=' * len(url)}\n\n")
                f.write(full_content)
            subprocess.Popen(["notepad.exe", filepath])

            summary_prompt = f"""Summarize this in exactly 1-2 short spoken sentences,
as if telling someone what you just read for them:

{full_content}"""
            summary_completion = _openai().chat.completions.create(
                model=settings["models"]["chat"],
                messages=[{"role": "user", "content": summary_prompt}],
            )
            summary = summary_completion.choices[0].message.content

            return f"{summary} I've opened the full summary in Notepad for you."
        except Exception as e:
            return f"I ran into an issue summarizing that: {e}"
