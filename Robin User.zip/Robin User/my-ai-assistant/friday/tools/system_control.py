import os
import subprocess
from pathlib import Path

from friday.settings import settings
from friday.tools.web import _chrome_path


def register(mcp):
    @mcp.tool()
    def open_application(app_name: str) -> str:
        """Open an application by name (e.g. 'notepad', 'chrome', 'calculator', 'explorer')."""
        try:
            # Bare "chrome" often isn't on PATH even when it's installed — see
            # friday/tools/web.py's _chrome_path() for why.
            target = _chrome_path() if app_name.strip().lower() == "chrome" else app_name
            subprocess.Popen(target, shell=True)
            return f"Opening {app_name}."
        except Exception as e:
            return f"Couldn't open {app_name}: {e}"

    @mcp.tool()
    def list_directory(path: str = "~") -> str:
        """List files and folders in a given directory. Defaults to the user's home folder."""
        p = Path(path).expanduser()
        if not p.exists():
            return f"Path {p} doesn't exist."
        try:
            items = [f.name for f in p.iterdir()][:50]
            return ", ".join(items) if items else "That folder is empty."
        except Exception as e:
            return f"Couldn't list {p}: {e}"

    @mcp.tool()
    def run_shell_command(command: str) -> str:
        """Run a safe, whitelisted shell command and return its output.
        Allowed commands: dir, echo, systeminfo, tasklist, ipconfig."""
        ALLOWED = ["dir", "echo", "systeminfo", "tasklist", "ipconfig"]
        first_word = command.strip().split(" ")[0].lower()
        if first_word not in ALLOWED:
            return f"Command '{first_word}' isn't in the allowed list for safety."
        try:
            result = subprocess.run(
                command, shell=True, capture_output=True, text=True, timeout=10
            )
            output = result.stdout or result.stderr
            return output[:1000] if output else "(no output)"
        except Exception as e:
            return f"Command failed: {e}"

    @mcp.tool()
    def workspace_launch() -> str:
        """Opens the user's typical daily workspace: apps and folders they use every day."""
        opened, failed = [], []
        # The list comes from [workspace] apps in settings.toml.
        for command in settings["workspace"]["apps"]:
            try:
                if command.strip().lower() == "chrome":
                    command = _chrome_path()
                subprocess.Popen(os.path.expandvars(command), shell=True)
                opened.append(command)
            except Exception as e:
                failed.append(f"{command} ({e})")
        if not opened and not failed:
            return "No workspace apps are set up yet — add some under [workspace] in settings.toml."
        result = f"Opened: {', '.join(opened)}." if opened else ""
        if failed:
            result += f" Couldn't open: {', '.join(failed)}."
        return result.strip()
