# Friday MCP Server Package
