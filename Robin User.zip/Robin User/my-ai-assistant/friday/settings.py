"""
User settings — loads settings.toml from the project root. Every value has a
default here, so a missing or partly-filled settings.toml still works.
"""

import sys
import tomllib
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SETTINGS_FILE = PROJECT_ROOT / "settings.toml"
DATA_DIR = PROJECT_ROOT / "data"

DEFAULTS = {
    "assistant": {
        "name": "Jarvis",
        "user_title": "sir",
        "personality": "You are calm, composed, and sharp. Speak like a trusted aide.",
    },
    "voice": {
        "tts_voice": "echo",
        "silence_threshold": 500,
        "silence_duration": 0.7,
        "follow_up_seconds": 90,
    },
    "models": {
        "chat": "gpt-4o-mini",
        "documents": "gpt-4o",
        "speech_to_text": "gpt-4o-mini-transcribe",
        "text_to_speech": "tts-1",
    },
    "hotkeys": {"mute": "ctrl+shift+m"},
    "hud": {"enabled": True, "width": 1920, "height": 1080},
    "workspace": {"apps": ["chrome", "code", "explorer %USERPROFILE%\\Downloads"]},
    "morning_briefing": {"enabled": True},
}


def _load() -> dict:
    merged = {section: dict(values) for section, values in DEFAULTS.items()}
    if not SETTINGS_FILE.exists():
        return merged
    try:
        with open(SETTINGS_FILE, "rb") as f:
            user = tomllib.load(f)
    except tomllib.TOMLDecodeError as e:
        sys.exit(f"\n❌ There's a typo in settings.toml: {e}\n"
                 f"   Fix it (check quotes and brackets) and start again.\n")
    for section, values in user.items():
        if isinstance(values, dict):
            merged.setdefault(section, {}).update(values)
    return merged


settings = _load()

ASSISTANT_NAME: str = settings["assistant"]["name"].strip() or "Jarvis"
USER_TITLE: str = settings["assistant"]["user_title"].strip()
PERSONALITY: str = settings["assistant"]["personality"].strip()


def address(text: str) -> str:
    """Appends the user's title to a phrase — address("Right away") -> "Right away, sir"."""
    return f"{text}, {USER_TITLE}" if USER_TITLE else text
