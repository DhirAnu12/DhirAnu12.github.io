"""Tiny shared time-formatting helper for the scheduling package."""

from datetime import datetime


def fmt_time(dt: datetime) -> str:
    """%-I / %#I are platform-specific strftime extensions (Unix vs. Windows) —
    this renders "7:00 AM" the same way on both."""
    return dt.strftime("%I:%M %p").lstrip("0")
