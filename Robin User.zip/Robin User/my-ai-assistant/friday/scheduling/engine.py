"""
Deterministic daily scheduling engine — generateDailySchedule from the spec.
This is the actual decision-maker; the LLM never constructs a schedule, it only
explains/narrates what this module already decided (see friday/scheduling/service.py
and the morning-briefing prompt work in a later stage).

Placement is a greedy, transparent pass: free time is computed first (freetime.py),
tasks are scored first (scoring.py), then for each free block — in chronological
order — the highest (score + placement-time bonus) eligible task is dropped in,
repeating until the block is full or nothing else fits. Every placed block gets a
plain-English `reason` straight from the score that won it the slot.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Optional

from friday.scheduling.freetime import category_allowed_at, compute_free_blocks, _parse_hm
from friday.scheduling.models import (
    CalendarEvent,
    FreeBlock,
    ScheduleBlock,
    ScheduleResult,
    ScoredTask,
    Task,
    UserPrefs,
)
from friday.scheduling.scoring import ScoringContext, compute_blocking_count, score_tasks
from friday.scheduling.timeutil import fmt_time as _fmt_time

MIN_USABLE_MINUTES = 10   # below this, a gap isn't worth trying to fill
DEFAULT_SPLIT_CHUNK = 25  # fallback minimum_work_block for splittable tasks that didn't set one
AT_RISK_HORIZON_HOURS = 48


def _time_of_day(dt: datetime) -> str:
    h = dt.hour
    if h < 12:
        return "morning"
    if h < 17:
        return "afternoon"
    return "evening"


def _is_high_energy_period(dt: datetime, prefs: UserPrefs) -> bool:
    t = dt.time()
    for period in prefs.high_energy_periods:
        if _parse_hm(period["start"]) <= t < _parse_hm(period["end"]):
            return True
    return False


def _placement_bonus(task: Task, at: datetime, prefs: UserPrefs, previous_category: Optional[str]) -> tuple[float, list[str]]:
    """Extra, time-slot-specific scoring on top of the task's base score —
    accounts for signals that only make sense once you know *where* a task
    would land (energy-period match, preferred time of day, context-switch cost)."""
    bonus = 0.0
    reasons: list[str] = []

    if task.energy_required == "high":
        if _is_high_energy_period(at, prefs):
            bonus += 1.5
            reasons.append("placed in a high-energy window")
        else:
            bonus -= 1.0

    tod = _time_of_day(at)
    if task.preferred_time_of_day and task.preferred_time_of_day != "any":
        if task.preferred_time_of_day == tod:
            bonus += 1.0
            reasons.append(f"scheduled in the {tod} as preferred")
        else:
            bonus -= 0.5

    if previous_category and task.category == previous_category:
        bonus += 0.75
        reasons.append(f"kept next to other {task.category} work to avoid context-switching")

    return bonus, reasons


def _build_reason(scored: ScoredTask, extra_reasons: list[str]) -> str:
    reasons = (extra_reasons + scored.reasons)[:2]
    if not reasons:
        return "Fit into available time."
    return "Scheduled because " + " and ".join(reasons) + "."


def _place_tasks(
    free_blocks: list[FreeBlock],
    scored: list[ScoredTask],
    prefs: UserPrefs,
    day: date,
) -> tuple[list[ScheduleBlock], list[str]]:
    """Greedy placement. Returns (placed_blocks, decision_log). Mutates nothing
    passed in — remaining-minutes bookkeeping is local."""
    blocks: list[ScheduleBlock] = []
    decisions: list[str] = []
    remaining_capacity = prefs.daily_work_capacity_minutes
    remaining_minutes = {s.task.id: s.task.duration_minutes for s in scored if s.task.id is not None}
    placed_before: set[int] = set()
    previous_category: Optional[str] = None

    for fb in free_blocks:
        cursor = fb.start
        while True:
            room = int((fb.end - cursor).total_seconds() // 60)
            if room < MIN_USABLE_MINUTES or remaining_capacity < MIN_USABLE_MINUTES:
                break

            candidates: list[tuple[float, ScoredTask, int, list[str]]] = []
            for s in scored:
                t = s.task
                if t.id is None or remaining_minutes.get(t.id, 0) <= 0:
                    continue
                full = remaining_minutes[t.id]
                if t.can_split:
                    min_chunk = t.minimum_work_block if t.minimum_work_block is not None else DEFAULT_SPLIT_CHUNK
                else:
                    min_chunk = full
                if min_chunk > room or min_chunk > remaining_capacity:
                    continue
                if t.earliest_start and cursor < t.earliest_start:
                    continue
                probe_end = cursor + timedelta(minutes=min(full, room))
                if not category_allowed_at(t.category, cursor, probe_end, prefs):
                    continue

                bonus, extra_reasons = _placement_bonus(t, cursor, prefs, previous_category)
                candidates.append((s.score + bonus, s, min_chunk, extra_reasons))

            if not candidates:
                break

            candidates.sort(key=lambda c: c[0], reverse=True)
            _, chosen, min_chunk, extra_reasons = candidates[0]
            t = chosen.task
            full = remaining_minutes[t.id]

            if t.can_split:
                chunk = min(full, room, remaining_capacity, prefs.max_deep_work_minutes)
                chunk = max(chunk, min_chunk)
            else:
                chunk = full

            start = cursor
            end = start + timedelta(minutes=chunk)
            reason = _build_reason(chosen, extra_reasons)

            blocks.append(ScheduleBlock(
                id=None,
                schedule_date=day.isoformat(),
                start_time=start,
                end_time=end,
                block_type="task",
                status="upcoming",
                task_id=t.id,
                reason=reason,
                locked=False,
                created_by="engine",
            ))
            verb = "Continued" if t.id in placed_before else "Scheduled"
            decisions.append(f'{verb} "{t.title}" {_fmt_time(start)}–{_fmt_time(end)}: {reason}')
            placed_before.add(t.id)

            remaining_minutes[t.id] -= chunk
            remaining_capacity -= chunk
            previous_category = t.category
            cursor = end

            if (fb.end - cursor).total_seconds() / 60 > prefs.min_buffer_minutes:
                cursor += timedelta(minutes=prefs.min_buffer_minutes)

    return blocks, decisions


def tasks_at_risk(tasks: list[Task], now: datetime) -> list[Task]:
    """Public: also used by service.py to flag deadline risk on the read path,
    without re-running the whole engine."""
    return [t for t in tasks if t.deadline and t.deadline <= now + timedelta(hours=AT_RISK_HORIZON_HOURS)]


def detect_conflicts(blocks: list[ScheduleBlock]) -> list[str]:
    """Public: also used by service.py on the read path."""
    ordered = sorted(blocks, key=lambda b: b.start_time)
    conflicts = []
    for a, b in zip(ordered, ordered[1:]):
        if b.start_time < a.end_time:
            conflicts.append(
                f"Overlap between {_fmt_time(a.start_time)}–{_fmt_time(a.end_time)} and "
                f"{_fmt_time(b.start_time)}–{_fmt_time(b.end_time)}."
            )
    return conflicts


def unfinished_tasks(tasks: list[Task], blocks: list[ScheduleBlock]) -> list[Task]:
    """Tasks not yet fully covered by the given blocks' placed minutes — public
    so service.py's read-only get_today_schedule can compute "unscheduled" from
    persisted blocks without re-deriving the engine's internal bookkeeping."""
    placed_minutes: dict[int, int] = {}
    for b in blocks:
        if b.task_id is not None:
            placed_minutes[b.task_id] = placed_minutes.get(b.task_id, 0) + b.duration_minutes
    return [t for t in tasks if t.id is None or placed_minutes.get(t.id, 0) < t.duration_minutes]


def generate_daily_schedule(
    day: date,
    tasks: list[Task],
    events: list[CalendarEvent],
    prefs: UserPrefs,
    context: ScoringContext,
    locked_blocks: Optional[list[ScheduleBlock]] = None,
) -> ScheduleResult:
    """
    generateDailySchedule(date, tasks, events, preferences, currentContext) from
    the spec. `tasks` should be every not-yet-done task (any status other than
    completed/cancelled) — dependency resolution treats "still present in this
    list" as "not done yet". `locked_blocks` are blocks the caller has already
    decided must stay put (used by replan_day); they're protected as busy time
    and returned untouched in the result.
    """
    locked_blocks = locked_blocks or []
    extra_busy = [(b.start_time, b.end_time) for b in locked_blocks]
    free_blocks = compute_free_blocks(day, events, prefs, now=context.now, extra_busy=extra_busy)

    active_ids = {t.id for t in tasks if t.id is not None}
    eligible, blocked = [], []
    for t in tasks:
        if any(dep in active_ids for dep in t.dependencies):
            blocked.append(t)
        else:
            eligible.append(t)

    context.blocking_count = compute_blocking_count(tasks)
    scored = score_tasks(eligible, context)

    placed_blocks, decisions = _place_tasks(free_blocks, scored, prefs, day)
    unscheduled = unfinished_tasks(eligible, placed_blocks) + blocked
    for t in blocked:
        decisions.append(f'"{t.title}" left unscheduled: waiting on a dependency that isn\'t done yet.')
    if not eligible and not blocked:
        decisions.append("Nothing left to schedule today.")

    event_blocks = [
        ScheduleBlock(
            id=None,
            schedule_date=day.isoformat(),
            start_time=ev.start_time,
            end_time=ev.end_time,
            block_type="meeting" if ev.event_type == "meeting" else "personal",
            status="upcoming",
            event_id=ev.id,
            reason=f"Fixed commitment: {ev.title}",
            locked=True,
            created_by="user",
        )
        for ev in events
    ]

    all_blocks = sorted(event_blocks + list(locked_blocks) + placed_blocks, key=lambda b: b.start_time)
    at_risk = tasks_at_risk(unscheduled, context.now)
    conflicts = detect_conflicts(all_blocks)

    top_priority = scored[0].task if scored else None
    next_action_text = None
    if placed_blocks:
        first = min(placed_blocks, key=lambda b: b.start_time)
        title = next((t.title for t in eligible if t.id == first.task_id), "your next task")
        next_action_text = f'Start "{title}" at {_fmt_time(first.start_time)} — {first.reason}'

    return ScheduleResult(
        date=day.isoformat(),
        blocks=all_blocks,
        unscheduled_tasks=unscheduled,
        conflicts=conflicts,
        at_risk_tasks=at_risk,
        top_priority_task=top_priority,
        recommended_next_action=next_action_text,
        decisions=decisions,
    )
