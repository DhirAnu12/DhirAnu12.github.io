"""
Natural-language command handlers — the seam between "the user said X" and
friday/scheduling/service.py. Plain top-level functions (not nested inside a
register(mcp) closure) so friday/tools/schedule.py (MCP) and the HUD
share the exact same implementation, per the spec: "Connect these commands to the
scheduling engine instead of asking the language model to improvise a schedule
from scratch." The LLM only picks which function to call and extracts
arguments — every actual scheduling decision happens in service.py's engine.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

from friday.scheduling import service as svc
from friday.scheduling.models import Task
from friday.scheduling.timeutil import fmt_time


def _resolve_target_block(task_title: str = "") -> tuple[Optional[int], Optional[str]]:
    """Finds the block matching task_title (case-insensitive substring) among
    today's task blocks, or falls back to whatever's currently active / coming
    up next if task_title is blank — covers "I finished THIS early" style
    commands where the LLM doesn't have (and shouldn't have to guess) an ID."""
    schedule = svc.get_today_schedule()
    task_blocks = [b for b in schedule.blocks if b.block_type == "task"]

    if task_title:
        tasks_by_id = {t.id: t for t in svc.list_tasks(include_all=True)}
        match = next(
            (b for b in task_blocks if tasks_by_id.get(b.task_id) and task_title.lower() in tasks_by_id[b.task_id].title.lower()),
            None,
        )
        if not match:
            return None, f"I couldn't find a task matching '{task_title}' on today's schedule."
        return match.id, None

    now = datetime.now()
    active = next((b for b in task_blocks if b.start_time <= now < b.end_time), None)
    if active:
        return active.id, None
    upcoming = sorted((b for b in task_blocks if b.start_time > now), key=lambda b: b.start_time)
    if upcoming:
        return upcoming[0].id, None
    return None, "You don't have an active or upcoming task block right now."


def plan_my_day(current_energy: str = "medium") -> str:
    """"Plan my day." Generates (or regenerates) today's schedule."""
    result = svc.generate_schedule(current_energy=current_energy)
    if not result.blocks:
        return "You've got a clear day — nothing fixed and nothing scheduled yet."
    lines = [
        f"{fmt_time(b.start_time)}–{fmt_time(b.end_time)}: {_block_label(b)}"
        for b in result.blocks
    ]
    header = f"Here's today — {len(result.blocks)} block(s) planned."
    if result.at_risk_tasks:
        header += f" {len(result.at_risk_tasks)} task(s) are at risk on deadline."
    return header + "\n" + "\n".join(lines)


def _block_label(block) -> str:
    if block.task_id:
        tasks_by_id = {t.id: t for t in svc.list_tasks(include_all=True)}
        task = tasks_by_id.get(block.task_id)
        return task.title if task else "Task"
    return block.reason or block.block_type


def what_should_i_do_next() -> str:
    """"What should I do next?" """
    action = svc.get_next_action()
    if not action.task:
        return action.reason
    text = f'{action.reason} Work on it for about {action.work_for_minutes} minutes.'
    if action.deadline_risk:
        text += f" Heads up: {action.deadline_risk}"
    return text


def i_finished_early(actual_minutes: Optional[int] = None, task_title: str = "") -> str:
    """"I finished this early."/"I'm done."""
    block_id, error = _resolve_target_block(task_title)
    if error:
        return error
    result = svc.complete_block(block_id, actual_minutes=actual_minutes)
    return result.summary


def this_took_longer(extra_minutes: int, task_title: str = "") -> str:
    """"This took longer than expected." — adds extra_minutes to the current task
    and replans the rest of the day around the overrun."""
    block_id, error = _resolve_target_block(task_title)
    if error:
        return error
    result = svc.extend_block(block_id, extra_minutes)
    return result.summary


def skip_this_task(disposition: str = "backlog", task_title: str = "") -> str:
    """"Skip this." disposition: later_today | tomorrow | backlog | cancel."""
    block_id, error = _resolve_target_block(task_title)
    if error:
        return error
    result = svc.skip_block(block_id, disposition=disposition)
    return result.summary


def move_task_to_tomorrow(task_title: str) -> str:
    """"Add this to tomorrow." / "Move this task [to tomorrow]." """
    block_id, error = _resolve_target_block(task_title)
    if error:
        return error
    result = svc.skip_block(block_id, disposition="tomorrow")
    return result.summary


def report_low_energy() -> str:
    """"I am tired." """
    result = svc.report_energy("low")
    return "Understood — lightening the rest of today. " + result.summary


def report_high_energy() -> str:
    """"I've got a ton of energy right now." """
    result = svc.report_energy("high")
    return "Good to hear — front-loading the harder work. " + result.summary


def report_free_time(minutes: int) -> str:
    """"I have two free hours." (pass minutes, e.g. 120)"""
    action = svc.report_availability(minutes, note=f"Reported {minutes} free minutes.")
    if not action.task:
        return action.reason
    return f'{action.reason} That should take about {action.work_for_minutes} of your {minutes} minutes.'


def what_can_safely_wait() -> str:
    """"What can safely wait?" """
    tasks = svc.what_can_safely_wait()
    if not tasks:
        return "Nothing looks safe to defer right now — everything left has some pull on it."
    return "These can wait without much risk: " + "; ".join(t.title for t in tasks)


def what_deadlines_are_at_risk() -> str:
    """"What deadlines are at risk?" """
    tasks = svc.deadlines_at_risk()
    if not tasks:
        return "No deadlines are at risk right now."
    lines = [
        f"- {t.title} (due {t.deadline.strftime('%a %I:%M %p').lstrip('0') if t.deadline else 'unknown'})"
        for t in tasks
    ]
    return "At risk:\n" + "\n".join(lines)


def replan_rest_of_day(detail: str = "Replanning the rest of the day.") -> str:
    """"Replan the rest of my day." """
    result = svc.replan_now(detail=detail)
    return result.summary


def add_task(
    title: str,
    description: str = "",
    priority: str = "medium",
    deadline_datetime: Optional[str] = None,
    estimated_duration_minutes: int = 30,
    category: Optional[str] = None,
    energy_required: str = "medium",
    can_split: bool = False,
    for_tomorrow: bool = False,
) -> str:
    """Creates a task. deadline_datetime, if given, must be "YYYY-MM-DD HH:MM"
    (24-hour) — same convention as set_reminder. Set for_tomorrow=True for
    "add this to tomorrow" style requests without a hard deadline."""
    deadline = None
    if deadline_datetime:
        try:
            deadline = datetime.strptime(deadline_datetime, "%Y-%m-%d %H:%M")
        except ValueError:
            return "I couldn't understand that deadline format."

    earliest_start = None
    if for_tomorrow:
        earliest_start = datetime.combine((datetime.now() + timedelta(days=1)).date(), datetime.min.time())

    task = Task(
        id=None,
        title=title,
        description=description or None,
        priority=priority,
        deadline=deadline,
        estimated_duration_minutes=estimated_duration_minutes,
        energy_required=energy_required,
        category=category,
        can_split=can_split,
        earliest_start=earliest_start,
    )
    created = svc.add_task(task)
    when = f" due {deadline.strftime('%a %I:%M %p').lstrip('0')}" if deadline else ""
    return f'Added "{created.title}"{when} to your task list.'
