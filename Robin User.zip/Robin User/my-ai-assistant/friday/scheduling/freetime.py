"""
Free-time calculation — steps 1-4 of the deterministic engine (see
friday/scheduling/engine.py): load fixed events, calculate open time blocks,
and remove sleep/meals/gym/travel/preparation/buffer periods. Pure function of
(day, events, prefs) — no I/O, so it's directly unit-testable.
"""

from __future__ import annotations

from datetime import date, datetime, time, timedelta
from typing import Optional

from friday.scheduling.models import CalendarEvent, FreeBlock, UserPrefs


def _parse_hm(value: str) -> time:
    h, m = value.split(":")
    return time(int(h), int(m))


def _at(day: date, t: time) -> datetime:
    return datetime.combine(day, t)


def waking_window(day: date, prefs: UserPrefs) -> tuple[datetime, datetime]:
    """The day's outer bound. Handles a sleeping_time past midnight (e.g. "00:30")
    by rolling it to the next calendar day rather than treating it as earlier
    than waking_time."""
    wake = _at(day, _parse_hm(prefs.waking_time))
    sleep = _at(day, _parse_hm(prefs.sleeping_time))
    if sleep <= wake:
        sleep += timedelta(days=1)
    return wake, sleep


def meal_blocks(day: date, prefs: UserPrefs) -> list[tuple[datetime, datetime]]:
    return [
        (_at(day, _parse_hm(meal["start"])), _at(day, _parse_hm(meal["end"])))
        for meal in prefs.meal_windows
    ]


def gym_block(day: date, prefs: UserPrefs, duration_minutes: int = 60) -> Optional[tuple[datetime, datetime]]:
    """The preferred gym slot, if configured — treated as a soft-fixed personal
    block removed from free time just like meals."""
    if not prefs.gym_time:
        return None
    start = _at(day, _parse_hm(prefs.gym_time))
    return start, start + timedelta(minutes=duration_minutes)


def category_allowed_at(category: Optional[str], start: datetime, end: datetime, prefs: UserPrefs) -> bool:
    """Checks a task's category against user_scheduling_prefs.category_time_restrictions,
    shaped as {"category": {"not_before": "HH:MM", "not_after": "HH:MM"}}."""
    if not category:
        return True
    rule = prefs.category_time_restrictions.get(category)
    if not rule:
        return True
    if rule.get("not_before"):
        if start.time() < _parse_hm(rule["not_before"]):
            return False
    if rule.get("not_after"):
        if end.time() > _parse_hm(rule["not_after"]):
            return False
    return True


def _merge_and_subtract(window: tuple[datetime, datetime], busy: list[tuple[datetime, datetime]]) -> list[FreeBlock]:
    """Subtracts a list of (possibly overlapping) busy intervals from one window,
    returning the sorted leftover FreeBlocks."""
    window_start, window_end = window
    intervals = sorted(
        (max(s, window_start), min(e, window_end))
        for s, e in busy
        if e > window_start and s < window_end
    )

    merged: list[tuple[datetime, datetime]] = []
    for s, e in intervals:
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))

    free: list[FreeBlock] = []
    cursor = window_start
    for s, e in merged:
        if s > cursor:
            free.append(FreeBlock(start=cursor, end=s))
        cursor = max(cursor, e)
    if cursor < window_end:
        free.append(FreeBlock(start=cursor, end=window_end))
    return free


def compute_free_blocks(
    day: date,
    events: list[CalendarEvent],
    prefs: UserPrefs,
    now: Optional[datetime] = None,
    min_block_minutes: int = 15,
    extra_busy: Optional[list[tuple[datetime, datetime]]] = None,
) -> list[FreeBlock]:
    """Returns the day's open FreeBlocks, net of sleep, fixed events (+ their
    travel/prep buffers), meals, gym, and any extra_busy spans (e.g. locked
    schedule blocks a replan must not touch) — in chronological order. `now`
    clips the start of "today" so the engine never offers already-past time."""
    wake, sleep = waking_window(day, prefs)
    window_start = wake
    if now is not None and now.date() == day and now > wake:
        window_start = now

    busy: list[tuple[datetime, datetime]] = []

    for ev in events:
        buffer_before = timedelta(minutes=ev.travel_buffer_minutes + ev.preparation_buffer_minutes)
        buffer_after = timedelta(minutes=ev.travel_buffer_minutes)
        busy.append((ev.start_time - buffer_before, ev.end_time + buffer_after))

    busy.extend(meal_blocks(day, prefs))

    gym = gym_block(day, prefs)
    if gym:
        busy.append(gym)

    if extra_busy:
        busy.extend(extra_busy)

    free = _merge_and_subtract((window_start, sleep), busy)
    return [b for b in free if b.minutes >= min_block_minutes]
