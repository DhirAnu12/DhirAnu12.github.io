"""
Scheduling domain models — plain dataclasses mirroring the tables in
the JSON files in data/. Kept free of any storage import so
the deterministic engine (freetime.py, scoring.py, engine.py, replan.py,
next_action.py) can be unit-tested with plain Python objects — friday/db/schedule.py
is the only module that translates these to/from stored rows.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal, Optional

TaskStatus = Literal[
    "inbox", "planned", "scheduled", "in_progress", "completed", "postponed", "cancelled"
]
Priority = Literal["critical", "high", "medium", "low"]
Energy = Literal["high", "medium", "low"]
TimeOfDay = Literal["morning", "afternoon", "evening", "any"]
BlockType = Literal["task", "meeting", "break", "meal", "travel", "buffer", "personal"]
BlockStatus = Literal["upcoming", "active", "completed", "skipped", "moved"]
CreatedBy = Literal["engine", "user"]

PRIORITY_WEIGHT: dict[str, float] = {"critical": 4.0, "high": 3.0, "medium": 2.0, "low": 1.0}
ENERGY_LEVEL: dict[str, int] = {"low": 1, "medium": 2, "high": 3}


def _iso(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat() if dt else None


def _parse_dt(value) -> Optional[datetime]:
    """Parses ISO-8601 timestamps read back from storage."""
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(value)


@dataclass
class Task:
    id: Optional[int]
    title: str
    description: Optional[str] = None
    status: TaskStatus = "inbox"
    priority: Priority = "medium"
    deadline: Optional[datetime] = None
    estimated_duration_minutes: Optional[int] = None
    remaining_duration_minutes: Optional[int] = None
    earliest_start: Optional[datetime] = None
    scheduled_start: Optional[datetime] = None
    scheduled_end: Optional[datetime] = None
    energy_required: Energy = "medium"
    category: Optional[str] = None
    project_id: Optional[str] = None
    can_split: bool = False
    minimum_work_block: Optional[int] = None
    dependencies: list[int] = field(default_factory=list)
    preferred_time_of_day: Optional[TimeOfDay] = None
    is_recurring: bool = False
    recurrence_rule: Optional[str] = None
    postponed_count: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    @property
    def duration_minutes(self) -> int:
        """Effective minutes still needed — remaining_duration_minutes once work has
        started, otherwise the original estimate (defaulting to 30 if neither is set,
        which only happens for hastily-created tasks)."""
        if self.remaining_duration_minutes is not None:
            return self.remaining_duration_minutes
        if self.estimated_duration_minutes is not None:
            return self.estimated_duration_minutes
        return 30

    @property
    def is_overdue(self) -> bool:
        return bool(self.deadline) and self.deadline < datetime.now(self.deadline.tzinfo)

    @classmethod
    def from_row(cls, row: dict) -> "Task":
        return cls(
            id=row.get("id"),
            title=row["title"],
            description=row.get("description"),
            status=row.get("status", "inbox"),
            priority=row.get("priority", "medium"),
            deadline=_parse_dt(row.get("deadline")),
            estimated_duration_minutes=row.get("estimated_duration_minutes"),
            remaining_duration_minutes=row.get("remaining_duration_minutes"),
            earliest_start=_parse_dt(row.get("earliest_start")),
            scheduled_start=_parse_dt(row.get("scheduled_start")),
            scheduled_end=_parse_dt(row.get("scheduled_end")),
            energy_required=row.get("energy_required", "medium"),
            category=row.get("category"),
            project_id=row.get("project_id"),
            can_split=row.get("can_split", False),
            minimum_work_block=row.get("minimum_work_block"),
            dependencies=list(row.get("dependencies") or []),
            preferred_time_of_day=row.get("preferred_time_of_day"),
            is_recurring=row.get("is_recurring", False),
            recurrence_rule=row.get("recurrence_rule"),
            postponed_count=row.get("postponed_count", 0),
            created_at=_parse_dt(row.get("created_at")),
            updated_at=_parse_dt(row.get("updated_at")),
            completed_at=_parse_dt(row.get("completed_at")),
        )

    def to_row(self) -> dict:
        return {
            "title": self.title,
            "description": self.description,
            "status": self.status,
            "priority": self.priority,
            "deadline": _iso(self.deadline),
            "estimated_duration_minutes": self.estimated_duration_minutes,
            "remaining_duration_minutes": self.remaining_duration_minutes,
            "earliest_start": _iso(self.earliest_start),
            "scheduled_start": _iso(self.scheduled_start),
            "scheduled_end": _iso(self.scheduled_end),
            "energy_required": self.energy_required,
            "category": self.category,
            "project_id": self.project_id,
            "can_split": self.can_split,
            "minimum_work_block": self.minimum_work_block,
            "dependencies": self.dependencies,
            "preferred_time_of_day": self.preferred_time_of_day,
            "is_recurring": self.is_recurring,
            "recurrence_rule": self.recurrence_rule,
            "postponed_count": self.postponed_count,
            "completed_at": _iso(self.completed_at),
        }


@dataclass
class CalendarEvent:
    id: Optional[int]
    title: str
    start_time: datetime
    end_time: datetime
    location: Optional[str] = None
    event_type: str = "meeting"
    is_fixed: bool = True
    travel_buffer_minutes: int = 0
    preparation_buffer_minutes: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @classmethod
    def from_row(cls, row: dict) -> "CalendarEvent":
        return cls(
            id=row.get("id"),
            title=row["title"],
            start_time=_parse_dt(row["start_time"]),
            end_time=_parse_dt(row["end_time"]),
            location=row.get("location"),
            event_type=row.get("event_type", "meeting"),
            is_fixed=row.get("is_fixed", True),
            travel_buffer_minutes=row.get("travel_buffer_minutes", 0),
            preparation_buffer_minutes=row.get("preparation_buffer_minutes", 0),
            created_at=_parse_dt(row.get("created_at")),
            updated_at=_parse_dt(row.get("updated_at")),
        )

    def to_row(self) -> dict:
        return {
            "title": self.title,
            "start_time": _iso(self.start_time),
            "end_time": _iso(self.end_time),
            "location": self.location,
            "event_type": self.event_type,
            "is_fixed": self.is_fixed,
            "travel_buffer_minutes": self.travel_buffer_minutes,
            "preparation_buffer_minutes": self.preparation_buffer_minutes,
        }


@dataclass
class ScheduleBlock:
    id: Optional[int]
    schedule_date: str  # "YYYY-MM-DD"
    start_time: datetime
    end_time: datetime
    block_type: BlockType = "task"
    status: BlockStatus = "upcoming"
    task_id: Optional[int] = None
    event_id: Optional[int] = None
    reason: str = ""
    locked: bool = False
    created_by: CreatedBy = "engine"
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @property
    def duration_minutes(self) -> int:
        return int((self.end_time - self.start_time).total_seconds() // 60)

    @classmethod
    def from_row(cls, row: dict) -> "ScheduleBlock":
        return cls(
            id=row.get("id"),
            schedule_date=row["schedule_date"],
            start_time=_parse_dt(row["start_time"]),
            end_time=_parse_dt(row["end_time"]),
            block_type=row.get("block_type", "task"),
            status=row.get("status", "upcoming"),
            task_id=row.get("task_id"),
            event_id=row.get("event_id"),
            reason=row.get("reason") or "",
            locked=row.get("locked", False),
            created_by=row.get("created_by", "engine"),
            created_at=_parse_dt(row.get("created_at")),
            updated_at=_parse_dt(row.get("updated_at")),
        )

    def to_row(self) -> dict:
        return {
            "schedule_date": self.schedule_date,
            "start_time": _iso(self.start_time),
            "end_time": _iso(self.end_time),
            "block_type": self.block_type,
            "status": self.status,
            "task_id": self.task_id,
            "event_id": self.event_id,
            "reason": self.reason,
            "locked": self.locked,
            "created_by": self.created_by,
        }


@dataclass
class UserPrefs:
    id: Optional[int] = None
    waking_time: str = "07:00"
    sleeping_time: str = "23:00"
    work_hours: dict = field(default_factory=lambda: {"start": "09:00", "end": "18:00"})
    gym_time: Optional[str] = None
    meal_windows: list = field(default_factory=lambda: [
        {"name": "breakfast", "start": "08:00", "end": "08:30"},
        {"name": "lunch", "start": "12:30", "end": "13:15"},
        {"name": "dinner", "start": "19:00", "end": "19:45"},
    ])
    max_deep_work_minutes: int = 120
    preferred_break_minutes: int = 10
    min_buffer_minutes: int = 10
    daily_work_capacity_minutes: int = 360
    high_energy_periods: list = field(default_factory=lambda: [{"start": "09:00", "end": "12:00"}])
    available_days: list = field(default_factory=lambda: ["mon", "tue", "wed", "thu", "fri", "sat", "sun"])
    category_time_restrictions: dict = field(default_factory=dict)
    timezone: str = "America/New_York"
    auto_replan_enabled: bool = True
    updated_at: Optional[datetime] = None

    @classmethod
    def from_row(cls, row: dict) -> "UserPrefs":
        return cls(
            id=row.get("id"),
            waking_time=row.get("waking_time", "07:00"),
            sleeping_time=row.get("sleeping_time", "23:00"),
            work_hours=row.get("work_hours") or {"start": "09:00", "end": "18:00"},
            gym_time=row.get("gym_time"),
            meal_windows=row.get("meal_windows") or [],
            max_deep_work_minutes=row.get("max_deep_work_minutes", 120),
            preferred_break_minutes=row.get("preferred_break_minutes", 10),
            min_buffer_minutes=row.get("min_buffer_minutes", 10),
            daily_work_capacity_minutes=row.get("daily_work_capacity_minutes", 360),
            high_energy_periods=row.get("high_energy_periods") or [],
            available_days=row.get("available_days") or [],
            category_time_restrictions=row.get("category_time_restrictions") or {},
            timezone=row.get("timezone", "America/New_York"),
            auto_replan_enabled=row.get("auto_replan_enabled", True),
            updated_at=_parse_dt(row.get("updated_at")),
        )

    def to_row(self) -> dict:
        return {
            "waking_time": self.waking_time,
            "sleeping_time": self.sleeping_time,
            "work_hours": self.work_hours,
            "gym_time": self.gym_time,
            "meal_windows": self.meal_windows,
            "max_deep_work_minutes": self.max_deep_work_minutes,
            "preferred_break_minutes": self.preferred_break_minutes,
            "min_buffer_minutes": self.min_buffer_minutes,
            "daily_work_capacity_minutes": self.daily_work_capacity_minutes,
            "high_energy_periods": self.high_energy_periods,
            "available_days": self.available_days,
            "category_time_restrictions": self.category_time_restrictions,
            "timezone": self.timezone,
            "auto_replan_enabled": self.auto_replan_enabled,
        }


@dataclass
class FreeBlock:
    """An open span of time on a given day, already net of fixed events + their
    buffers, sleep, and meals — what the engine actually places tasks into."""
    start: datetime
    end: datetime

    @property
    def minutes(self) -> int:
        return int((self.end - self.start).total_seconds() // 60)


@dataclass
class ScoredTask:
    task: Task
    score: float
    reasons: list[str]


@dataclass
class ScheduleResult:
    date: str
    blocks: list[ScheduleBlock]
    unscheduled_tasks: list[Task]
    conflicts: list[str]
    at_risk_tasks: list[Task]
    top_priority_task: Optional[Task]
    recommended_next_action: Optional[str]
    decisions: list[str]  # human-readable reasons for major scheduling decisions


@dataclass
class ReplanResult:
    date: str
    trigger: str
    blocks: list[ScheduleBlock]
    changes: list[str]  # human-readable "what changed and why" lines
    summary: str        # one paragraph, LLM-friendly
    bumped_task_ids: list[int] = field(default_factory=list)  # tasks moved/dropped — service.py increments postponed_count for these


@dataclass
class NextAction:
    task: Optional[Task]
    block: Optional[ScheduleBlock]
    reason: str
    work_for_minutes: int
    start_immediately: bool
    alternative_task: Optional[Task]
    deadline_risk: Optional[str]


@dataclass
class WeeklyPlanResult:
    week_start: str
    outcomes: list[str]
    day_assignments: dict[str, list]     # "mon".."sun" -> [Task, ...] once hydrated (or [task_id, ...] pre-hydration)
    unassigned_backlog: list[Task]
    overloaded_days: list[str]
    deadline_risks: list[Task]
    workload_by_category: dict[str, int]  # minutes
