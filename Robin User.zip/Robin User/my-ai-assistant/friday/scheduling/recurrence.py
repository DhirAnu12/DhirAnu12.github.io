"""
Recurring-task support. Deliberately simple per the spec ("do not build complex
ML/scheduling initially") — a handful of plain-English rules, not an RFC 5545
RRULE parser. `recurrence_rule` is one of: "daily", "weekdays", "weekly", or
"every_N_days" (e.g. "every_3_days").
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional


def next_occurrence(rule: Optional[str], from_dt: datetime) -> Optional[datetime]:
    """Returns the next occurrence strictly after from_dt, or None if the rule
    is missing/unrecognized (caller should treat that as "not actually recurring")."""
    if not rule:
        return None
    rule = rule.strip().lower()

    if rule == "daily":
        return from_dt + timedelta(days=1)

    if rule == "weekly":
        return from_dt + timedelta(days=7)

    if rule == "weekdays":
        nxt = from_dt + timedelta(days=1)
        while nxt.weekday() >= 5:  # 5=Sat, 6=Sun
            nxt += timedelta(days=1)
        return nxt

    if rule.startswith("every_") and rule.endswith("_days"):
        try:
            n = int(rule.split("_")[1])
            if n > 0:
                return from_dt + timedelta(days=n)
        except (IndexError, ValueError):
            pass

    return None
