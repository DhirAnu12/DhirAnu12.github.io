"""
Weekly planning — generateWeeklyPlan(weekStart, tasks, events, goals, preferences)
from the spec. Deliberately day-level, not hour-level: "Avoid locking every task
into an exact hour too early... detailed time-blocking should happen through
each day's adaptive schedule" (friday/scheduling/engine.py). This just decides
*which day* each task should land on, respecting deadlines, priority, and each
day's remaining capacity after fixed events.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Optional

from friday.scheduling.models import CalendarEvent, PRIORITY_WEIGHT, Task, UserPrefs, WeeklyPlanResult

DAY_KEYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


def _day_capacity(days: list[date], day_keys: list[str], events: list[CalendarEvent], prefs: UserPrefs) -> dict[str, int]:
    event_minutes = {k: 0 for k in day_keys}
    for ev in events:
        for i, d in enumerate(days):
            if ev.start_time.date() == d:
                event_minutes[day_keys[i]] += int((ev.end_time - ev.start_time).total_seconds() // 60)

    capacity = {}
    for k in day_keys:
        if k not in prefs.available_days:
            capacity[k] = 0
        else:
            capacity[k] = max(prefs.daily_work_capacity_minutes - event_minutes[k], 0)
    return capacity


def _sort_key(task: Task, week_start: date, week_end: date):
    has_deadline_this_week = bool(task.deadline) and week_start <= task.deadline.date() <= week_end
    return (
        0 if has_deadline_this_week else 1,
        task.deadline or datetime.max,
        -PRIORITY_WEIGHT.get(task.priority, 2.0),
    )


def generate_weekly_plan(
    week_start: date,
    tasks: list[Task],
    events: list[CalendarEvent],
    goals: list[str],
    prefs: UserPrefs,
) -> WeeklyPlanResult:
    """`week_start` is treated as the first day of a 7-day window (doesn't have
    to be a Monday). Recurring tasks (habits) are excluded from day assignment —
    they're expected on every available day, not a single one — but still count
    toward workload_by_category."""
    days = [week_start + timedelta(days=i) for i in range(7)]
    day_keys = [DAY_KEYS[d.weekday()] for d in days]
    week_end = days[-1]

    capacity = _day_capacity(days, day_keys, events, prefs)
    used = {k: 0 for k in day_keys}
    assignments: dict[str, list[int]] = {k: [] for k in day_keys}
    unassigned: list[Task] = []

    schedulable = [t for t in tasks if not t.is_recurring and t.id is not None]
    ordered = sorted(schedulable, key=lambda t: _sort_key(t, week_start, week_end))

    for t in ordered:
        dur = max(t.duration_minutes, 0)

        if t.deadline and week_start <= t.deadline.date() <= week_end:
            deadline_idx = (t.deadline.date() - week_start).days
            candidate_indices = list(range(0, deadline_idx + 1))
        else:
            candidate_indices = list(range(7))

        placed = False
        for i in candidate_indices:
            k = day_keys[i]
            if used[k] + dur <= capacity[k]:
                assignments[k].append(t.id)
                used[k] += dur
                placed = True
                break

        if not placed:
            if candidate_indices and t.deadline and week_start <= t.deadline.date() <= week_end:
                # Deadline-bound task with nowhere it cleanly fits — force it onto
                # its least-loaded eligible day rather than silently dropping it;
                # this is exactly what should surface as an overloaded day.
                k = day_keys[min(candidate_indices, key=lambda i: used[day_keys[i]])]
                assignments[k].append(t.id)
                used[k] += dur
            else:
                unassigned.append(t)

    overloaded_days = [k for k in day_keys if used[k] > capacity[k]]
    assigned_ids = {tid for ids in assignments.values() for tid in ids}
    deadline_risks = [
        t for t in tasks
        if t.deadline and week_start <= t.deadline.date() <= week_end and t.id not in assigned_ids
    ]

    workload_by_category: dict[str, int] = {}
    for t in tasks:
        cat = t.category or "uncategorized"
        workload_by_category[cat] = workload_by_category.get(cat, 0) + max(t.duration_minutes, 0)

    return WeeklyPlanResult(
        week_start=week_start.isoformat(),
        outcomes=list(goals or []),
        day_assignments=assignments,
        unassigned_backlog=unassigned,
        overloaded_days=overloaded_days,
        deadline_risks=deadline_risks,
        workload_by_category=workload_by_category,
    )
