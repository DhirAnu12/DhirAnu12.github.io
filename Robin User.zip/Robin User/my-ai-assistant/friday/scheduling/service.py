"""
Scheduling service — the seam between local persistence (friday/db/schedule.py)
and the deterministic, pure-Python engine (freetime/scoring/engine/next_action/
replan). Every caller — the MCP tools (friday/tools/schedule.py) and the
desktop HUD — goes through this module, so there's exactly one place that decides
how a trigger maps to a DB write plus a recomputed schedule.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import date, datetime, timedelta
from typing import Optional

from friday.db import schedule as db
from friday.scheduling.engine import detect_conflicts, generate_daily_schedule, tasks_at_risk, unfinished_tasks
from friday.scheduling.models import (
    CalendarEvent,
    NextAction,
    ReplanResult,
    ScheduleBlock,
    ScheduleResult,
    Task,
    UserPrefs,
    WeeklyPlanResult,
)
from friday.scheduling.next_action import get_recommended_next_action
from friday.scheduling.recurrence import next_occurrence
from friday.scheduling.replan import replan_day
from friday.scheduling.scoring import ScoringContext, score_tasks
from friday.scheduling.weekly import generate_weekly_plan

# In-memory "how the user says they're feeling right now" — deliberately not persisted;
# it's a live signal for the current session, not a fact about the task/schedule graph.
# Resets to "medium" on process restart, which is fine (a fresh morning briefing re-asks).
_current_energy = "medium"


def _today() -> date:
    return datetime.now().date()


def set_current_energy(level: str) -> None:
    global _current_energy
    _current_energy = level


def _load_day_inputs(day: date) -> tuple[list[Task], list[CalendarEvent], UserPrefs]:
    tasks = db.list_active_tasks()
    day_start = datetime.combine(day, datetime.min.time())
    events = db.list_events_between(day_start, day_start + timedelta(days=1))
    prefs = db.get_prefs()
    return tasks, events, prefs


def _event_blocks_for(day: date, events: list[CalendarEvent]) -> list[ScheduleBlock]:
    return [
        ScheduleBlock(
            id=None,
            schedule_date=day.isoformat(),
            start_time=ev.start_time,
            end_time=ev.end_time,
            block_type="meeting" if ev.event_type == "meeting" else "personal",
            status="upcoming",
            event_id=ev.id,
            reason=f"Fixed commitment: {ev.title}",
            locked=True,
            created_by="user",
        )
        for ev in events
    ]


def _persist_blocks(day: date, blocks: list[ScheduleBlock], now: datetime) -> list[ScheduleBlock]:
    """Replaces the day's non-protected task blocks with a freshly-generated
    set. Fixed-event blocks are never written here — they're synthesized live
    from calendar_events on every read, so they can never go stale."""
    db.delete_unlocked_blocks_for_date(day.isoformat(), now=now)
    task_blocks = [b for b in blocks if b.event_id is None]
    to_insert = [b for b in task_blocks if b.id is None]
    to_keep = [b for b in task_blocks if b.id is not None]
    inserted = db.create_blocks(to_insert) if to_insert else []
    return inserted + to_keep


def get_today_schedule(day: Optional[date] = None) -> ScheduleResult:
    """Read-only — today's persisted blocks + live derived fields (unscheduled,
    at-risk, conflicts, next action). Does not regenerate; call generate_schedule
    or replan_now for that."""
    day = day or _today()
    tasks, events, prefs = _load_day_inputs(day)
    now = datetime.now()
    context = ScoringContext(now=now, current_energy=_current_energy)

    persisted = db.get_blocks_for_date(day.isoformat())
    all_blocks = sorted(persisted + _event_blocks_for(day, events), key=lambda b: b.start_time)

    unscheduled = unfinished_tasks(tasks, persisted)
    at_risk = tasks_at_risk(unscheduled, now)
    conflicts = detect_conflicts(all_blocks)

    scored = score_tasks(tasks, context)
    top_priority = scored[0].task if scored else None

    result = ScheduleResult(
        date=day.isoformat(),
        blocks=all_blocks,
        unscheduled_tasks=unscheduled,
        conflicts=conflicts,
        at_risk_tasks=at_risk,
        top_priority_task=top_priority,
        recommended_next_action=None,
        decisions=[],
    )
    action = get_recommended_next_action(now, result, tasks, context)
    result.recommended_next_action = action.reason
    return result


def get_week_schedule(week_start: date) -> list[ScheduleResult]:
    """Today view reused across 7 days — the week page is a thin read over the
    same persisted blocks, no separate storage (see friday/scheduling/weekly.py
    for the day-assignment layer that feeds this)."""
    return [get_today_schedule(week_start + timedelta(days=i)) for i in range(7)]


def _run_engine_and_persist(trigger: str, detail: str, day: date, now: datetime) -> ReplanResult:
    tasks, events, prefs = _load_day_inputs(day)
    context = ScoringContext(now=now, current_energy=_current_energy)

    current_blocks = sorted(
        db.get_blocks_for_date(day.isoformat()) + _event_blocks_for(day, events),
        key=lambda b: b.start_time,
    )

    result = replan_day(trigger, day, current_blocks, tasks, events, prefs, context, trigger_detail=detail)
    persisted = _persist_blocks(day, result.blocks, now)
    result.blocks = sorted(persisted + [b for b in result.blocks if b.event_id is not None], key=lambda b: b.start_time)

    for task_id in result.bumped_task_ids:
        task = next((t for t in tasks if t.id == task_id), None)
        if task is not None:
            db.update_task(task_id, postponed_count=task.postponed_count + 1)

    db.log_history(
        change_type="replanned",
        entity_type="schedule",
        explanation=result.summary,
        trigger=trigger,
        actor="user" if trigger == "manual" else "engine",
        snapshot=[b.to_row() | {"id": b.id} for b in result.blocks],
    )
    return result


def generate_schedule(day: Optional[date] = None, current_energy: Optional[str] = None) -> ScheduleResult:
    """generateDailySchedule wired to the DB — "Plan my day." Reuses the replan
    machinery so anything already completed/active/locked today survives a
    re-generate instead of being wiped."""
    if current_energy:
        set_current_energy(current_energy)
    day = day or _today()
    now = datetime.now()
    _run_engine_and_persist("generate", "", day, now)
    return get_today_schedule(day)


def replan_now(detail: str = "Replanning the rest of the day.", day: Optional[date] = None) -> ReplanResult:
    day = day or _today()
    return _run_engine_and_persist("manual", detail, day, datetime.now())


# ---------------------------------------------------------------------------
# Block actions (HUD + Today-view controls)
# ---------------------------------------------------------------------------

def _require_task_block(block_id: int) -> ScheduleBlock:
    block = db.get_block(block_id)
    if block is None:
        raise ValueError(f"No such block: {block_id}")
    if block.block_type != "task":
        raise ValueError(f"Block {block_id} is a fixed {block.block_type}, not a task — nothing to start/pause.")
    return block


def start_block(block_id: int) -> ScheduleBlock:
    _require_task_block(block_id)
    return db.update_block(block_id, status="active")


def pause_block(block_id: int) -> ScheduleBlock:
    _require_task_block(block_id)
    return db.update_block(block_id, status="upcoming")


def lock_block(block_id: int, locked: bool = True) -> ScheduleBlock:
    if db.get_block(block_id) is None:
        raise ValueError(f"No such block: {block_id}")
    block = db.update_block(block_id, locked=locked)
    db.log_history(
        change_type="block_locked" if locked else "block_unlocked",
        entity_type="block",
        entity_id=block_id,
        explanation=f'{"Locked" if locked else "Unlocked"} the {block.start_time.strftime("%I:%M %p").lstrip("0")} block.',
        trigger="user_manual_lock",
        actor="user",
    )
    return block


def complete_block(block_id: int, actual_minutes: Optional[int] = None) -> ReplanResult:
    """"Mark complete" / "I finished this" — records actual duration if given,
    marks the task done if this closes out its remaining time, then replans the
    rest of the day around the freed-up (or overrun) time."""
    block = db.get_block(block_id)
    if block is None:
        raise ValueError(f"No such block: {block_id}")
    if block.status in ("completed", "skipped"):
        raise ValueError(f'Block {block_id} is already {block.status} — nothing to complete.')

    now = datetime.now()
    planned_minutes = block.duration_minutes
    actual = actual_minutes if actual_minutes is not None else planned_minutes
    db.update_block(block_id, status="completed", end_time=(block.start_time + timedelta(minutes=actual)).isoformat())

    detail = ""
    task = db.get_task(block.task_id) if block.task_id else None
    if task:
        base_remaining = task.remaining_duration_minutes if task.remaining_duration_minutes is not None else task.duration_minutes
        remaining = max(base_remaining - actual, 0)
        db.log_duration(task.id, task.category, planned_minutes, actual)

        if remaining <= 0 and task.is_recurring:
            # Fully done for today's occurrence — roll it forward instead of
            # closing it out, so a recurring task actually recurs.
            nxt = next_occurrence(task.recurrence_rule, now)
            if nxt is not None:
                new_deadline = None
                if task.deadline:
                    shift = next_occurrence(task.recurrence_rule, task.deadline)
                    new_deadline = shift.isoformat() if shift else None
                db.update_task(
                    task.id,
                    status="planned",
                    remaining_duration_minutes=None,
                    earliest_start=nxt.isoformat(),
                    deadline=new_deadline,
                    completed_at=None,
                )
            else:
                # Recognized as recurring but no usable rule — fall back to a
                # normal one-off completion rather than losing the task.
                db.update_task(task.id, remaining_duration_minutes=0, status="completed", completed_at=now.isoformat())
        else:
            db.update_task(
                task.id,
                remaining_duration_minutes=remaining,
                status="completed" if remaining <= 0 else "in_progress",
                completed_at=now.isoformat() if remaining <= 0 else None,
            )

        diff = actual - planned_minutes
        if diff >= 10:
            detail = f'"{task.title}" took {diff} minutes longer than expected.'
            trigger = "task_completed_late"
        elif diff <= -10:
            detail = f'"{task.title}" finished {abs(diff)} minutes early.'
            trigger = "task_completed_early"
        else:
            detail = f'"{task.title}" is done.'
            trigger = "task_completed_early"
    else:
        trigger = "task_completed_early"

    return _run_engine_and_persist(trigger, detail, date.fromisoformat(block.schedule_date), now)


def skip_block(block_id: int, disposition: str = "backlog") -> ReplanResult:
    """disposition: 'later_today' | 'tomorrow' | 'backlog' | 'cancel'."""
    block = db.get_block(block_id)
    if block is None:
        raise ValueError(f"No such block: {block_id}")
    if block.status in ("completed", "skipped"):
        raise ValueError(f'Block {block_id} is already {block.status} — nothing to skip.')
    now = datetime.now()
    db.update_block(block_id, status="skipped")

    task = db.get_task(block.task_id) if block.task_id else None
    detail = ""
    if task:
        if disposition == "cancel":
            db.update_task(task.id, status="cancelled")
            detail = f'Cancelled "{task.title}".'
        elif disposition == "tomorrow":
            tomorrow = now + timedelta(days=1)
            db.update_task(task.id, status="postponed", earliest_start=tomorrow.isoformat())
            detail = f'Moved "{task.title}" to tomorrow.'
        elif disposition == "backlog":
            db.update_task(task.id, status="postponed", earliest_start=None)
            detail = f'Sent "{task.title}" back to the backlog.'
        else:  # later_today
            detail = f'Skipped "{task.title}" for now — leaving it eligible for later today.'

    return _run_engine_and_persist("task_skipped", detail, date.fromisoformat(block.schedule_date), now)


def extend_block(block_id: int, extra_minutes: int) -> ReplanResult:
    block = db.get_block(block_id)
    if block is None:
        raise ValueError(f"No such block: {block_id}")
    if block.status in ("completed", "skipped"):
        raise ValueError(f'Block {block_id} is already {block.status} — nothing to extend.')
    if extra_minutes <= 0:
        raise ValueError("extra_minutes must be positive.")
    now = datetime.now()
    new_end = block.end_time + timedelta(minutes=extra_minutes)
    db.update_block(block_id, end_time=new_end.isoformat())

    detail = ""
    task = db.get_task(block.task_id) if block.task_id else None
    if task:
        base_remaining = task.remaining_duration_minutes if task.remaining_duration_minutes is not None else task.duration_minutes
        remaining = base_remaining + extra_minutes
        db.update_task(task.id, remaining_duration_minutes=remaining)
        detail = f'"{task.title}" needs {extra_minutes} more minutes.'

    return _run_engine_and_persist("task_completed_late", detail, date.fromisoformat(block.schedule_date), now)


def move_block(block_id: int, new_start: datetime, new_end: datetime) -> ReplanResult:
    """User drag/resize on the Today view — treated as intentional: the moved
    block is auto-locked so a subsequent replan can't undo it (per spec)."""
    block = db.get_block(block_id)
    if block is None:
        raise ValueError(f"No such block: {block_id}")
    if block.block_type != "task":
        raise ValueError(f"Block {block_id} is a fixed {block.block_type} — unlock/edit the calendar event instead of dragging it.")
    if new_end <= new_start:
        raise ValueError("A block's end time must be after its start time.")
    now = datetime.now()
    db.update_block(
        block_id,
        start_time=new_start.isoformat(),
        end_time=new_end.isoformat(),
        locked=True,
        created_by="user",
    )
    detail = "You moved a block manually — keeping it where you put it."
    return _run_engine_and_persist("block_locked_or_moved", detail, date.fromisoformat(block.schedule_date), now)


# ---------------------------------------------------------------------------
# Tasks / events (CRUD + the triggers they imply)
# ---------------------------------------------------------------------------

def add_task(task: Task, auto_replan: bool = True) -> Task:
    created = db.create_task(task)
    if auto_replan and db.get_prefs().auto_replan_enabled:
        _run_engine_and_persist("new_task_added", f'Added "{created.title}" to today\'s plan.', _today(), datetime.now())
    return created


def update_task_deadline(task_id: int, new_deadline: Optional[datetime], auto_replan: bool = True) -> Task:
    updated = db.update_task(task_id, deadline=new_deadline.isoformat() if new_deadline else None)
    if auto_replan and db.get_prefs().auto_replan_enabled:
        _run_engine_and_persist("deadline_changed", f'"{updated.title}"\'s deadline changed.', _today(), datetime.now())
    return updated


REPLAN_WORTHY_FIELDS = {
    "deadline", "priority", "estimated_duration_minutes", "remaining_duration_minutes",
    "status", "earliest_start", "energy_required", "can_split",
}


def update_task_fields(task_id: int, auto_replan: bool = True, **fields) -> Task:
    """Generic task edit (title, description, category, ...) for the Today-view
    "edit task details" action. Only re-plans when a field that actually affects
    placement changed — a title/description edit shouldn't trigger a re-run."""
    updated = db.update_task(task_id, **fields)
    if auto_replan and REPLAN_WORTHY_FIELDS & fields.keys() and db.get_prefs().auto_replan_enabled:
        _run_engine_and_persist("manual", f'Updated "{updated.title}".', _today(), datetime.now())
    return updated


def list_tasks(include_all: bool = False) -> list[Task]:
    return db.list_tasks() if include_all else db.list_active_tasks()


def get_task(task_id: int) -> Optional[Task]:
    return db.get_task(task_id)


def delete_task(task_id: int) -> bool:
    return db.delete_task(task_id)


def list_events_for_range(start: datetime, end: datetime) -> list[CalendarEvent]:
    return db.list_events_between(start, end)


def get_preferences() -> UserPrefs:
    return db.get_prefs()


def update_preferences(**fields) -> UserPrefs:
    return db.update_prefs(**fields)


def add_event(event: CalendarEvent, auto_replan: bool = True) -> CalendarEvent:
    created = db.create_event(event)
    if auto_replan and db.get_prefs().auto_replan_enabled and created.start_time.date() == _today():
        _run_engine_and_persist("event_added", f'Added "{created.title}" to your calendar.', _today(), datetime.now())
    return created


def cancel_event(event_id: int, auto_replan: bool = True) -> None:
    event = None
    events_today = db.list_events_between(
        datetime.combine(_today(), datetime.min.time()), datetime.combine(_today() + timedelta(days=1), datetime.min.time())
    )
    event = next((e for e in events_today if e.id == event_id), None)
    db.delete_event(event_id)
    if auto_replan and event and db.get_prefs().auto_replan_enabled:
        _run_engine_and_persist("event_cancelled", f'Cancelled "{event.title}" — freeing up that time.', _today(), datetime.now())


def report_energy(level: str) -> ReplanResult:
    """"I am tired" / "I have a ton of energy" -> low_energy / high_energy trigger."""
    set_current_energy(level)
    trigger = "low_energy" if level == "low" else "high_energy" if level == "high" else "manual"
    return _run_engine_and_persist(trigger, "", _today(), datetime.now())


def report_availability(extra_minutes: int, note: str = "") -> NextAction:
    """"I have two free hours" — doesn't change stored data (no calendar event
    actually changed), just re-surfaces the best next action for that window
    and logs the report so it shows up in the activity history."""
    day = _today()
    now = datetime.now()
    tasks, _events, _prefs = _load_day_inputs(day)
    context = ScoringContext(now=now, current_energy=_current_energy)
    schedule = get_today_schedule(day)
    action = get_recommended_next_action(now, schedule, tasks, context)
    db.log_history(
        change_type="availability_reported",
        entity_type="schedule",
        explanation=note or f"You reported {extra_minutes} free minutes. {action.reason}",
        trigger="became_available",
        actor="user",
    )
    return action


def get_next_action() -> NextAction:
    day = _today()
    now = datetime.now()
    tasks, _events, _prefs = _load_day_inputs(day)
    context = ScoringContext(now=now, current_energy=_current_energy)
    schedule = get_today_schedule(day)
    return get_recommended_next_action(now, schedule, tasks, context)


def what_can_safely_wait(day: Optional[date] = None) -> list[Task]:
    """Lowest-scored, no-near-deadline tasks among today's unscheduled/backlog —
    "What can safely wait?"."""
    day = day or _today()
    now = datetime.now()
    tasks, _events, _prefs = _load_day_inputs(day)
    context = ScoringContext(now=now, current_energy=_current_energy)
    scored = score_tasks(tasks, context)
    risky_ids = {t.id for t in tasks_at_risk(tasks, now)}
    safe = [s.task for s in scored if s.task.id not in risky_ids and s.task.priority in ("low", "medium")]
    return safe[-5:] if len(safe) > 5 else safe


def deadlines_at_risk(day: Optional[date] = None) -> list[Task]:
    day = day or _today()
    tasks, _events, _prefs = _load_day_inputs(day)
    return tasks_at_risk(tasks, datetime.now())


def get_history(limit: int = 50) -> list[dict]:
    return db.list_history(limit=limit)


# ---------------------------------------------------------------------------
# Weekly planning
# ---------------------------------------------------------------------------

def _hydrate_weekly_plan(row: dict, tasks_by_id: dict[int, Task]) -> dict:
    def hydrate_ids(ids: list) -> list[Task]:
        return [tasks_by_id[tid] for tid in ids if tid in tasks_by_id]

    return {
        "week_start": row["week_start"],
        "outcomes": row.get("outcomes") or [],
        "day_assignments": {k: hydrate_ids(v) for k, v in (row.get("day_assignments") or {}).items()},
        "unassigned_backlog": hydrate_ids(row.get("unassigned_backlog") or []),
        "overloaded_days": row.get("overloaded_days") or [],
        "deadline_risks": hydrate_ids(row.get("deadline_risks") or []),
        "workload_by_category": row.get("workload_by_category") or {},
    }


def generate_weekly_plan_for(week_start: date, goals: Optional[list[str]] = None) -> dict:
    """generateWeeklyPlan wired to the DB — persists day-level assignments to
    the weekly_plans table, then hydrates task ids back into full Task objects
    for the caller."""
    tasks = db.list_active_tasks()
    week_end_exclusive = datetime.combine(week_start + timedelta(days=7), datetime.min.time())
    events = db.list_events_between(datetime.combine(week_start, datetime.min.time()), week_end_exclusive)
    prefs = db.get_prefs()

    existing = db.get_weekly_plan(week_start.isoformat())
    outcomes = goals if goals is not None else ((existing or {}).get("outcomes") or [])

    result = generate_weekly_plan(week_start, tasks, events, outcomes, prefs)

    db.upsert_weekly_plan(
        week_start.isoformat(),
        outcomes=result.outcomes,
        day_assignments=result.day_assignments,
        unassigned_backlog=[t.id for t in result.unassigned_backlog],
        overloaded_days=result.overloaded_days,
        deadline_risks=[t.id for t in result.deadline_risks],
        workload_by_category=result.workload_by_category,
    )
    db.log_history(
        change_type="weekly_plan_generated",
        entity_type="schedule",
        explanation=f"Generated the week of {week_start.isoformat()} — {len(result.overloaded_days)} overloaded day(s), {len(result.unassigned_backlog)} task(s) couldn't fit.",
        trigger="generate_weekly_plan",
        actor="engine",
    )

    by_id = {t.id: t for t in tasks}
    return _hydrate_weekly_plan(db.get_weekly_plan(week_start.isoformat()), by_id)


def get_weekly_plan_for(week_start: date) -> Optional[dict]:
    row = db.get_weekly_plan(week_start.isoformat())
    if row is None:
        return None
    tasks = db.list_tasks()  # include all statuses so completed-this-week tasks still resolve
    by_id = {t.id: t for t in tasks}
    return _hydrate_weekly_plan(row, by_id)


def set_weekly_goals(week_start: date, goals: list[str]) -> dict:
    """Updates just the week's declared outcomes without re-running assignment —
    "Change weekly priorities" without forcing a full regenerate."""
    existing = db.get_weekly_plan(week_start.isoformat())
    if existing is None:
        return generate_weekly_plan_for(week_start, goals=goals)
    db.upsert_weekly_plan(week_start.isoformat(), outcomes=goals)
    tasks = db.list_tasks()
    return _hydrate_weekly_plan(db.get_weekly_plan(week_start.isoformat()), {t.id: t for t in tasks})


# ---------------------------------------------------------------------------
# Manual / self-serve scheduling — for the Planner page, where the user places
# things directly instead of asking the assistant to figure it out.
# ---------------------------------------------------------------------------

def add_task_at_time(task: Task, start: datetime, end: datetime) -> tuple[Task, ScheduleBlock]:
    """Directly places a brand-new task at a specific time — user-authored, so
    (like move_block) it's created already locked and never touched by a
    replan. This is the "click an empty hour to add something" path."""
    if end <= start:
        raise ValueError("A block's end time must be after its start time.")

    created = db.create_task(replace(
        task, status="scheduled",
        estimated_duration_minutes=int((end - start).total_seconds() // 60),
        scheduled_start=start, scheduled_end=end,
    ))
    block = db.create_blocks([ScheduleBlock(
        id=None,
        schedule_date=start.date().isoformat(),
        start_time=start,
        end_time=end,
        block_type="task",
        status="upcoming",
        task_id=created.id,
        reason="Added directly to your schedule.",
        locked=True,
        created_by="user",
    )])[0]
    db.log_history(
        change_type="task_added_manually",
        entity_type="task",
        entity_id=created.id,
        explanation=f'You added "{created.title}" directly at {block.start_time.strftime("%I:%M %p").lstrip("0")}.',
        trigger="user_manual_add",
        actor="user",
    )
    return created, block


def complete_task_directly(task_id: int, actual_minutes: Optional[int] = None) -> dict:
    """Marks a task done without going through a schedule block — for the
    Planner page's To-Do/Habits panels, where checking something off doesn't
    necessarily correspond to a timeline block. Recurring tasks roll forward,
    same as complete_block; also closes out any of today's still-open blocks
    for this task so the Today timeline doesn't show it as dangling."""
    task = db.get_task(task_id)
    if task is None:
        raise ValueError(f"No such task: {task_id}")
    if task.status == "completed" and not task.is_recurring:
        raise ValueError(f'"{task.title}" is already completed.')

    now = datetime.now()
    planned = task.duration_minutes
    actual = actual_minutes if actual_minutes is not None else planned
    db.log_duration(task.id, task.category, planned, actual)

    today_blocks = [
        b for b in db.get_blocks_for_date(now.date().isoformat())
        if b.task_id == task.id and b.status not in ("completed", "skipped")
    ]
    for b in today_blocks:
        db.update_block(b.id, status="completed")

    if task.is_recurring:
        nxt = next_occurrence(task.recurrence_rule, now)
        if nxt is not None:
            new_deadline = None
            if task.deadline:
                shifted = next_occurrence(task.recurrence_rule, task.deadline)
                new_deadline = shifted.isoformat() if shifted else None
            db.update_task(
                task.id, status="planned", remaining_duration_minutes=None,
                earliest_start=nxt.isoformat(), deadline=new_deadline, completed_at=None,
            )
            db.log_history(
                change_type="habit_completed", entity_type="task", entity_id=task.id,
                explanation=f'Checked off "{task.title}" for today.', trigger="user_manual_complete", actor="user",
            )
            return {"task_id": task.id, "status": "planned", "recurring": True}

    db.update_task(task.id, status="completed", remaining_duration_minutes=0, completed_at=now.isoformat())
    db.log_history(
        change_type="task_completed", entity_type="task", entity_id=task.id,
        explanation=f'Checked off "{task.title}".', trigger="user_manual_complete", actor="user",
    )
    return {"task_id": task.id, "status": "completed", "recurring": False}


def list_habits() -> list[dict]:
    """Recurring tasks with today's completion state and a simple day-count
    streak computed from task_duration_log — for the Planner page's Habits panel."""
    tasks = [t for t in db.list_tasks() if t.is_recurring]
    today = datetime.now().date()
    out = []
    for t in tasks:
        log = db.list_duration_log(task_id=t.id, limit=90)
        done_dates = sorted({datetime.fromisoformat(r["recorded_at"]).date() for r in log}, reverse=True)
        done_today = bool(done_dates) and done_dates[0] == today

        streak = 0
        cursor = today if done_today else today - timedelta(days=1)
        for d in done_dates:
            if d == cursor:
                streak += 1
                cursor -= timedelta(days=1)
            elif d < cursor:
                break

        out.append({"task": t, "done_today": done_today, "streak": streak})
    return out


def list_todos(day: Optional[date] = None) -> list[Task]:
    """Non-recurring, not-yet-scheduled tasks — the Planner page's To-Do panel
    (habits get their own panel via list_habits, so they're excluded here)."""
    schedule = get_today_schedule(day)
    return [t for t in schedule.unscheduled_tasks if not t.is_recurring]


def add_habit(title: str, recurrence_rule: str = "daily", estimated_duration_minutes: int = 15, category: Optional[str] = None) -> Task:
    task = Task(
        id=None, title=title, priority="low", status="planned",
        estimated_duration_minutes=estimated_duration_minutes,
        category=category, is_recurring=True, recurrence_rule=recurrence_rule,
    )
    return db.create_task(task)
