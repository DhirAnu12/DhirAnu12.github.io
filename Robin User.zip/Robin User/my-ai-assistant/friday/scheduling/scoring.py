"""
Task scoring — a separate, transparent service so the weighting can be tuned
without touching the engine that consumes it. Every score comes back with the
plain-English reasons that drove it, which the engine surfaces as each block's
`reason` field.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from friday.scheduling.models import ENERGY_LEVEL, PRIORITY_WEIGHT, ScoredTask, Task

DEADLINE_HORIZON_HOURS = 72  # urgency ramps up sharply inside this window


@dataclass
class ScoringContext:
    now: datetime
    current_energy: str = "medium"                                 # high | medium | low
    previous_category: Optional[str] = None                        # last task placed, for context-switch cost
    blocking_count: dict[int, int] = field(default_factory=dict)    # task_id -> tasks that depend on it
    project_importance: dict[str, float] = field(default_factory=dict)  # project_id -> 0..1


def _deadline_urgency(task: Task, now: datetime) -> tuple[float, Optional[str]]:
    if not task.deadline:
        return 0.0, None
    hours_left = (task.deadline - now).total_seconds() / 3600
    if hours_left < 0:
        return 10.0, "it is overdue"
    if hours_left <= 24:
        return 8.0, "it is due today"
    if hours_left <= DEADLINE_HORIZON_HOURS:
        ramp = 1 - (hours_left - 24) / (DEADLINE_HORIZON_HOURS - 24)
        return 2.0 + 6.0 * ramp, "it is due soon"
    if hours_left <= 24 * 7:
        return 1.0, "it is due this week"
    return 0.0, None


def score_task(task: Task, context: ScoringContext) -> ScoredTask:
    reasons: list[str] = []
    score = 0.0

    # Priority
    score += PRIORITY_WEIGHT.get(task.priority, 2.0) * 2
    if task.priority in ("critical", "high"):
        reasons.append(f"{task.priority} priority")

    # Deadline urgency (includes overdue)
    urgency, urgency_reason = _deadline_urgency(task, context.now)
    score += urgency
    if urgency_reason:
        reasons.append(urgency_reason)

    # Dependency impact — unblocks other work
    blockers = context.blocking_count.get(task.id, 0) if task.id is not None else 0
    if blockers:
        score += min(blockers, 5) * 1.5
        reasons.append(f"unblocks {blockers} other task{'s' if blockers != 1 else ''}")

    # Importance to a longer-term project/goal
    importance = context.project_importance.get(task.project_id, 0.0) if task.project_id else 0.0
    score += importance * 3

    # Already postponed — nudge upward so it doesn't get stuck in the backlog
    # forever, capped so one chronically-deferred low-priority task can't
    # dominate every day (replan.py tracks postponed_count on every bump).
    if task.postponed_count:
        score += min(task.postponed_count, 4) * 0.75
        reasons.append(f"already postponed {task.postponed_count}x")

    # Progress already made — finishing beats abandoning
    if task.estimated_duration_minutes and task.remaining_duration_minutes is not None:
        progress = 1 - (task.remaining_duration_minutes / max(task.estimated_duration_minutes, 1))
        if progress > 0.05:
            score += progress * 2
            reasons.append(f"{int(progress * 100)}% already done")

    # Energy compatibility with the user's reported current energy
    task_level = ENERGY_LEVEL.get(task.energy_required, 2)
    current_level = ENERGY_LEVEL.get(context.current_energy, 2)
    if task_level == current_level:
        score += 1.0
        reasons.append("matches your current energy")
    elif task_level > current_level:
        score -= 1.5  # asking for more focus than the user reports having right now

    # Context-switching cost — small bonus for staying in the same category as
    # whatever was just placed, so the day doesn't hop topics every 30 minutes.
    if context.previous_category and task.category == context.previous_category:
        score += 0.75
        reasons.append(f"continues {task.category} work")

    # Effort — mild penalty for very large asks, so one huge task doesn't
    # automatically crowd out several smaller wins.
    score -= min(task.duration_minutes / 480, 1.0) * 0.5

    return ScoredTask(task=task, score=round(score, 2), reasons=reasons)


def score_tasks(tasks: list[Task], context: ScoringContext) -> list[ScoredTask]:
    """Scores and sorts tasks highest-value first."""
    scored = [score_task(t, context) for t in tasks]
    scored.sort(key=lambda s: s.score, reverse=True)
    return scored


def compute_blocking_count(tasks: list[Task]) -> dict[int, int]:
    """How many other tasks list each task as a dependency — feeds
    ScoringContext.blocking_count so unblocking work is rewarded."""
    counts: dict[int, int] = {}
    for t in tasks:
        for dep_id in t.dependencies:
            counts[dep_id] = counts.get(dep_id, 0) + 1
    return counts
