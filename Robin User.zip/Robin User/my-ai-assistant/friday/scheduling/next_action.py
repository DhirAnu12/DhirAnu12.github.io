"""
Next-action engine — getRecommendedNextAction(currentTime, schedule, tasks, context)
from the spec. This reads today's already-generated ScheduleResult rather than
re-deciding anything; it's a query over the plan the deterministic engine already
produced, not a second scheduler.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

from friday.scheduling.models import NextAction, ScheduleBlock, ScheduleResult, Task
from friday.scheduling.scoring import ScoringContext, score_tasks
from friday.scheduling.timeutil import fmt_time

MIN_RECOMMENDED_MINUTES = 10
DEFAULT_GAP_HOURS = 4  # assumed free runway when nothing fixed is left today


def _active_block(blocks: list[ScheduleBlock], now: datetime) -> Optional[ScheduleBlock]:
    for b in blocks:
        if b.start_time <= now < b.end_time and b.status not in ("completed", "skipped"):
            return b
    return None


def _next_block(blocks: list[ScheduleBlock], now: datetime) -> Optional[ScheduleBlock]:
    upcoming = [b for b in blocks if b.start_time > now and b.status == "upcoming"]
    return min(upcoming, key=lambda b: b.start_time) if upcoming else None


def _deadline_risk_text(task: Optional[Task], now: datetime) -> Optional[str]:
    if not task or not task.deadline:
        return None
    hours_left = (task.deadline - now).total_seconds() / 3600
    if hours_left < 0:
        return f'"{task.title}" is overdue.'
    if hours_left <= 24:
        return f'"{task.title}" is due within {max(int(hours_left), 1)} hour(s).'
    return None


def get_recommended_next_action(
    now: datetime,
    schedule: ScheduleResult,
    tasks: list[Task],
    context: ScoringContext,
) -> NextAction:
    by_id = {t.id: t for t in tasks if t.id is not None}
    remaining = [t for t in tasks if t.status not in ("completed", "cancelled")]

    active = _active_block(schedule.blocks, now)

    if active and active.block_type == "task" and active.task_id in by_id:
        task = by_id[active.task_id]
        minutes_left = max(int((active.end_time - now).total_seconds() // 60), 1)
        others = score_tasks([t for t in remaining if t.id != task.id], context)
        alt = others[0].task if others else None
        return NextAction(
            task=task,
            block=active,
            reason=active.reason or "This is what's currently on your schedule.",
            work_for_minutes=minutes_left,
            start_immediately=True,
            alternative_task=alt,
            deadline_risk=_deadline_risk_text(task, now),
        )

    if active and active.block_type != "task":
        label = active.reason or active.block_type
        return NextAction(
            task=None,
            block=active,
            reason=f'You\'re in "{label}" until {fmt_time(active.end_time)}.',
            work_for_minutes=0,
            start_immediately=False,
            alternative_task=None,
            deadline_risk=None,
        )

    nxt = _next_block(schedule.blocks, now)
    if nxt:
        gap_minutes = max(int((nxt.start_time - now).total_seconds() // 60), 0)
    else:
        gap_minutes = DEFAULT_GAP_HOURS * 60

    scored = score_tasks(remaining, context)
    if not scored:
        return NextAction(None, None, "Nothing left on your plate right now.", 0, False, None, None)

    top = scored[0].task
    if gap_minutes < MIN_RECOMMENDED_MINUTES:
        reason = f'Your next commitment starts in {gap_minutes} minutes — too tight to start "{top.title}".'
        return NextAction(
            task=top, block=None, reason=reason, work_for_minutes=0,
            start_immediately=False, alternative_task=scored[1].task if len(scored) > 1 else None,
            deadline_risk=_deadline_risk_text(top, now),
        )

    work_minutes = max(min(top.duration_minutes, gap_minutes), MIN_RECOMMENDED_MINUTES)
    reason_bits = scored[0].reasons[:2] or ["it's the best use of this open time"]
    reason = f'Work on "{top.title}" — ' + " and ".join(reason_bits) + "."
    if nxt:
        reason += f" Your next fixed commitment starts in {gap_minutes} minutes."

    return NextAction(
        task=top,
        block=None,
        reason=reason,
        work_for_minutes=work_minutes,
        start_immediately=True,
        alternative_task=scored[1].task if len(scored) > 1 else None,
        deadline_risk=_deadline_risk_text(top, now),
    )
