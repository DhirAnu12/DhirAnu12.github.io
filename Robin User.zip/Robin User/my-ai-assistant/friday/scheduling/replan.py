"""
Adaptive replanning — replanDay(trigger, currentSchedule, tasks, events,
currentContext) from the spec.

replan_day is a pure function: it assumes the CALLER (friday/scheduling/service.py)
has already applied the trigger's direct effect to the data before invoking it —
e.g. marking a block completed, adjusting a task's remaining_duration_minutes after
"this took longer than expected", inserting a new calendar event. replan_day's job
is narrower: figure out which blocks must stay untouched (completed, in-progress,
locked, or already in the past), clear everything else, and re-run the same
deterministic engine over just the remaining portion of the day — then explain
what moved and why.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import date
from typing import Literal

from friday.scheduling.engine import generate_daily_schedule
from friday.scheduling.models import CalendarEvent, ReplanResult, ScheduleBlock, Task, UserPrefs
from friday.scheduling.scoring import ScoringContext
from friday.scheduling.timeutil import fmt_time

ReplanTrigger = Literal[
    "task_completed_early",
    "task_completed_late",
    "task_skipped",
    "new_task_added",
    "deadline_changed",
    "event_added",
    "event_cancelled",
    "low_energy",
    "high_energy",
    "became_available",
    "time_passed_block",
    "block_locked_or_moved",
    "manual",
]

TRIGGER_OPENERS: dict[str, str] = {
    "low_energy": "You reported low energy, so I lightened the rest of today.",
    "high_energy": "You reported high energy, so I front-loaded harder work.",
    "became_available": "You've got unexpected free time, so I pulled work forward.",
    "time_passed_block": "A scheduled block ran past its window, so I recalculated the rest of the day.",
}


def _blocks_by_task(blocks: list[ScheduleBlock]) -> dict[int, list[ScheduleBlock]]:
    out: dict[int, list[ScheduleBlock]] = {}
    for b in blocks:
        if b.task_id is not None:
            out.setdefault(b.task_id, []).append(b)
    return out


def replan_day(
    trigger: str,
    day: date,
    current_blocks: list[ScheduleBlock],
    tasks: list[Task],
    events: list[CalendarEvent],
    prefs: UserPrefs,
    context: ScoringContext,
    trigger_detail: str = "",
) -> ReplanResult:
    now = context.now

    # Protect: completed, in-progress, explicitly locked, or already-started
    # task blocks. Fixed events aren't included here — generate_daily_schedule
    # always rebuilds event blocks fresh from `events`, so they're untouched by
    # construction, not by being carried over.
    protected = [
        b for b in current_blocks
        if b.block_type == "task" and (b.locked or b.status in ("completed", "active") or b.start_time <= now)
    ]
    protected_minutes: dict[int, int] = {}
    for b in protected:
        if b.task_id is not None:
            protected_minutes[b.task_id] = protected_minutes.get(b.task_id, 0) + b.duration_minutes

    # Only the remaining, not-yet-covered portion of each task goes back into
    # the pool the engine re-places — otherwise a task that's already 90%
    # scheduled via protected blocks would get over-booked again.
    adjusted_tasks: list[Task] = []
    for t in tasks:
        if t.status in ("completed", "cancelled"):
            continue
        remaining = t.duration_minutes - protected_minutes.get(t.id, 0)
        if remaining <= 0:
            continue
        adjusted_tasks.append(replace(t, remaining_duration_minutes=remaining))

    protected_ids = {id(b) for b in protected}
    old_future_by_task = _blocks_by_task(
        [b for b in current_blocks if b.block_type == "task" and id(b) not in protected_ids]
    )

    result = generate_daily_schedule(day, adjusted_tasks, events, prefs, context, locked_blocks=protected)

    new_by_task = _blocks_by_task(
        [b for b in result.blocks if b.block_type == "task" and b.created_by == "engine"]
    )

    changes: list[str] = []
    moved_or_dropped_task_ids: list[int] = []

    for task_id, old_blocks in old_future_by_task.items():
        task = next((t for t in tasks if t.id == task_id), None)
        title = task.title if task else f"Task {task_id}"
        old_start = min(b.start_time for b in old_blocks)
        new_blocks = new_by_task.get(task_id)

        if not new_blocks:
            changes.append(f'Moved "{title}" out of today — no room left in the remaining schedule.')
            moved_or_dropped_task_ids.append(task_id)
            continue

        new_start = min(b.start_time for b in new_blocks)
        if new_start != old_start:
            changes.append(
                f'Moved "{title}" from {fmt_time(old_start)} to {fmt_time(new_start)} — {new_blocks[0].reason}'
            )
            moved_or_dropped_task_ids.append(task_id)

    for task_id, new_blocks in new_by_task.items():
        if task_id not in old_future_by_task:
            task = next((t for t in tasks if t.id == task_id), None)
            title = task.title if task else f"Task {task_id}"
            new_start = min(b.start_time for b in new_blocks)
            changes.append(f'Fit "{title}" in at {fmt_time(new_start)} — {new_blocks[0].reason}')

    if not changes:
        changes.append("No changes were needed — today's plan still holds.")

    opener = trigger_detail or TRIGGER_OPENERS.get(trigger, "")
    summary = " ".join(p for p in [opener, *changes] if p)

    return ReplanResult(
        date=day.isoformat(),
        trigger=trigger,
        blocks=result.blocks,
        changes=changes,
        summary=summary,
        bumped_task_ids=moved_or_dropped_task_ids,
    )
