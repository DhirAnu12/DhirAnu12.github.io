"""
Local JSON storage — a tiny table store that keeps everything in the data/
folder on your own computer. No accounts, no cloud database, no keys.

Each table is one JSON file: {"next_id": 7, "rows": [{...}, ...]}.
The voice agent and the MCP server are separate processes that both read and
write these files, so every read-modify-write runs under a cross-process lock
and files are replaced atomically (never left half-written).
"""

import json
import msvcrt
import os
import time
from contextlib import contextmanager
from datetime import date, datetime
from typing import Callable, Iterator, Optional

from friday.settings import DATA_DIR

_LOCK_PATH = DATA_DIR / ".lock"


def _json_default(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    raise TypeError(f"Can't store {type(value).__name__} in JSON")


@contextmanager
def _locked() -> Iterator[None]:
    DATA_DIR.mkdir(exist_ok=True)
    with open(_LOCK_PATH, "a+b") as lock_file:
        while True:
            try:
                lock_file.seek(0)
                msvcrt.locking(lock_file.fileno(), msvcrt.LK_NBLCK, 1)
                break
            except OSError:
                time.sleep(0.02)
        try:
            yield
        finally:
            lock_file.seek(0)
            msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)


class Table:
    def __init__(self, name: str, timestamp_fields: tuple[str, ...] = ("created_at", "updated_at")):
        self.path = DATA_DIR / f"{name}.json"
        self.timestamp_fields = timestamp_fields

    # -- raw file access (callers must hold the lock) -----------------------

    def _read(self) -> dict:
        if not self.path.exists():
            return {"next_id": 1, "rows": []}
        with open(self.path, encoding="utf-8") as f:
            return json.load(f)

    def _write(self, data: dict) -> None:
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=_json_default)
        os.replace(tmp, self.path)

    @contextmanager
    def edit(self) -> Iterator[dict]:
        """Locks the table, yields its data for in-place changes, then saves it."""
        with _locked():
            data = self._read()
            yield data
            self._write(data)

    # -- queries ------------------------------------------------------------

    def all(self) -> list[dict]:
        with _locked():
            return self._read()["rows"]

    def where(self, predicate: Callable[[dict], bool]) -> list[dict]:
        return [r for r in self.all() if predicate(r)]

    def get(self, row_id: int) -> Optional[dict]:
        return next((r for r in self.all() if r["id"] == row_id), None)

    # -- writes -------------------------------------------------------------

    def insert(self, row: dict) -> dict:
        return self.insert_many([row])[0]

    def insert_many(self, rows: list[dict]) -> list[dict]:
        now = datetime.now().isoformat()
        created = []
        with self.edit() as data:
            for row in rows:
                new_row = json.loads(json.dumps(row, default=_json_default))
                new_row["id"] = data["next_id"]
                data["next_id"] += 1
                for field in self.timestamp_fields:
                    new_row.setdefault(field, now)
                data["rows"].append(new_row)
                created.append(new_row)
        return created

    def update(self, row_id: int, **fields) -> dict:
        fields = json.loads(json.dumps(fields, default=_json_default))
        with self.edit() as data:
            for row in data["rows"]:
                if row["id"] == row_id:
                    row.update(fields)
                    return row
        raise KeyError(f"No row with id {row_id} in {self.path.name}")

    def delete_where(self, predicate: Callable[[dict], bool]) -> list[dict]:
        with self.edit() as data:
            removed = [r for r in data["rows"] if predicate(r)]
            data["rows"] = [r for r in data["rows"] if not predicate(r)]
        return removed

    def delete(self, row_id: int) -> bool:
        return bool(self.delete_where(lambda r: r["id"] == row_id))
