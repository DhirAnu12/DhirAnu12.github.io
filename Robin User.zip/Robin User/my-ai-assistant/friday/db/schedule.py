"""
Scheduling store — tasks, calendar events, schedule blocks, preferences,
history, and duration tracking, saved locally as JSON files in data/.

Pure data access here, translating rows <-> friday/scheduling/models dataclasses —
no scheduling logic. The deterministic engine (friday/scheduling/engine.py etc.)
never imports this module directly; friday/scheduling/service.py is the seam that
wires the pure engine to this persistence layer, so the engine stays unit-testable
without touching disk.
"""

from datetime import date, datetime, timedelta
from typing import Optional

from friday.db.local_store import Table
from friday.scheduling.models import CalendarEvent, ScheduleBlock, Task, UserPrefs, _parse_dt

TASKS = Table("tasks")
EVENTS = Table("calendar_events")
BLOCKS = Table("schedule_blocks")
PREFS = Table("user_scheduling_prefs", timestamp_fields=("updated_at",))
HISTORY = Table("schedule_history", timestamp_fields=("occurred_at",))
DURATION_LOG = Table("task_duration_log", timestamp_fields=("recorded_at",))
WEEKLY_PLANS = Table("weekly_plans")

ACTIVE_TASK_STATUSES = ["inbox", "planned", "scheduled", "in_progress", "postponed"]


def _now() -> str:
    return datetime.now().isoformat()


# ---------------------------------------------------------------------------
# Tasks
# ---------------------------------------------------------------------------

def create_task(task: Task) -> Task:
    return Task.from_row(TASKS.insert(task.to_row()))


def update_task(task_id: int, **fields) -> Task:
    return Task.from_row(TASKS.update(task_id, updated_at=_now(), **fields))


def get_task(task_id: int) -> Optional[Task]:
    row = TASKS.get(task_id)
    return Task.from_row(row) if row else None


def list_tasks(statuses: Optional[list[str]] = None) -> list[Task]:
    rows = TASKS.all()
    if statuses:
        rows = [r for r in rows if r["status"] in statuses]
    rows.sort(key=lambda r: r["created_at"])
    return [Task.from_row(r) for r in rows]


def list_active_tasks() -> list[Task]:
    """Everything schedulable — excludes completed/cancelled."""
    return list_tasks(statuses=ACTIVE_TASK_STATUSES)


def delete_task(task_id: int) -> bool:
    deleted = TASKS.delete(task_id)
    if deleted:
        BLOCKS.delete_where(lambda r: r.get("task_id") == task_id)
        with DURATION_LOG.edit() as data:
            for row in data["rows"]:
                if row.get("task_id") == task_id:
                    row["task_id"] = None
    return deleted


# ---------------------------------------------------------------------------
# Calendar events
# ---------------------------------------------------------------------------

def create_event(event: CalendarEvent) -> CalendarEvent:
    return CalendarEvent.from_row(EVENTS.insert(event.to_row()))


def update_event(event_id: int, **fields) -> CalendarEvent:
    return CalendarEvent.from_row(EVENTS.update(event_id, updated_at=_now(), **fields))


def delete_event(event_id: int) -> bool:
    deleted = EVENTS.delete(event_id)
    if deleted:
        BLOCKS.delete_where(lambda r: r.get("event_id") == event_id)
    return deleted


def list_events_between(start: datetime, end: datetime) -> list[CalendarEvent]:
    events = [CalendarEvent.from_row(r) for r in EVENTS.all()]
    overlapping = [e for e in events if e.start_time < end and e.end_time > start]
    return sorted(overlapping, key=lambda e: e.start_time)


def list_events_for_date(day: date) -> list[CalendarEvent]:
    start = datetime.combine(day, datetime.min.time())
    return list_events_between(start, start + timedelta(days=1))


# ---------------------------------------------------------------------------
# Schedule blocks
# ---------------------------------------------------------------------------

def _sorted_blocks(rows: list[dict]) -> list[ScheduleBlock]:
    return sorted((ScheduleBlock.from_row(r) for r in rows), key=lambda b: b.start_time)


def get_blocks_for_date(schedule_date: str) -> list[ScheduleBlock]:
    return _sorted_blocks(BLOCKS.where(lambda r: r["schedule_date"] == schedule_date))


def get_blocks_for_range(start_date: str, end_date: str) -> list[ScheduleBlock]:
    return _sorted_blocks(BLOCKS.where(lambda r: start_date <= r["schedule_date"] <= end_date))


def get_block(block_id: int) -> Optional[ScheduleBlock]:
    row = BLOCKS.get(block_id)
    return ScheduleBlock.from_row(row) if row else None


def create_blocks(blocks: list[ScheduleBlock]) -> list[ScheduleBlock]:
    if not blocks:
        return []
    return [ScheduleBlock.from_row(r) for r in BLOCKS.insert_many([b.to_row() for b in blocks])]


def update_block(block_id: int, **fields) -> ScheduleBlock:
    return ScheduleBlock.from_row(BLOCKS.update(block_id, updated_at=_now(), **fields))


def delete_unlocked_blocks_for_date(
    schedule_date: str,
    now: Optional[datetime] = None,
    exclude_statuses: tuple[str, ...] = ("completed", "active"),
) -> None:
    """Clears out engine-owned blocks for a day before regenerating. Mirrors
    friday/scheduling/replan.py's protection rule exactly (locked OR completed/
    active OR already started) — the two must stay in sync, otherwise a replan
    can delete a block the engine believed it was protecting."""
    def removable(r: dict) -> bool:
        return (
            r["schedule_date"] == schedule_date
            and not r.get("locked", False)
            and r.get("status") not in exclude_statuses
            and (now is None or _parse_dt(r["start_time"]) > now)
        )

    BLOCKS.delete_where(removable)


# ---------------------------------------------------------------------------
# Preferences (a single row)
# ---------------------------------------------------------------------------

def get_prefs() -> UserPrefs:
    rows = PREFS.all()
    if rows:
        return UserPrefs.from_row(rows[0])
    return UserPrefs.from_row(PREFS.insert(UserPrefs().to_row()))


def update_prefs(**fields) -> UserPrefs:
    prefs = get_prefs()  # ensures a row exists
    return UserPrefs.from_row(PREFS.update(prefs.id, updated_at=_now(), **fields))


# ---------------------------------------------------------------------------
# History / activity log
# ---------------------------------------------------------------------------

def log_history(
    change_type: str,
    entity_type: str,
    explanation: str,
    entity_id: Optional[int] = None,
    previous_value: Optional[dict] = None,
    new_value: Optional[dict] = None,
    trigger: Optional[str] = None,
    actor: str = "engine",
    snapshot: Optional[list[dict]] = None,
) -> dict:
    return HISTORY.insert({
        "change_type": change_type,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "previous_value": previous_value,
        "new_value": new_value,
        "trigger": trigger,
        "actor": actor,
        "explanation": explanation,
        "snapshot": snapshot,
    })


def list_history(limit: int = 50) -> list[dict]:
    rows = sorted(HISTORY.all(), key=lambda r: (r["occurred_at"], r["id"]), reverse=True)
    return rows[:limit]


def get_history_entry(history_id: int) -> Optional[dict]:
    return HISTORY.get(history_id)


# ---------------------------------------------------------------------------
# Duration tracking (estimate vs. actual)
# ---------------------------------------------------------------------------

def log_duration(task_id: int, category: Optional[str], estimated_minutes: Optional[int], actual_minutes: int) -> dict:
    return DURATION_LOG.insert({
        "task_id": task_id,
        "category": category,
        "estimated_minutes": estimated_minutes,
        "actual_minutes": actual_minutes,
    })


def list_duration_log(task_id: Optional[int] = None, category: Optional[str] = None, limit: int = 200) -> list[dict]:
    rows = DURATION_LOG.all()
    if task_id is not None:
        rows = [r for r in rows if r.get("task_id") == task_id]
    if category:
        rows = [r for r in rows if r.get("category") == category]
    rows.sort(key=lambda r: (r["recorded_at"], r["id"]), reverse=True)
    return rows[:limit]


# ---------------------------------------------------------------------------
# Weekly plans
# ---------------------------------------------------------------------------

def get_weekly_plan(week_start: str) -> Optional[dict]:
    return next(iter(WEEKLY_PLANS.where(lambda r: r["week_start"] == week_start)), None)


def upsert_weekly_plan(week_start: str, **fields) -> dict:
    existing = get_weekly_plan(week_start)
    if existing:
        return WEEKLY_PLANS.update(existing["id"], updated_at=_now(), **fields)
    defaults = {
        "outcomes": [],
        "day_assignments": {},
        "unassigned_backlog": [],
        "overloaded_days": [],
        "deadline_risks": [],
        "workload_by_category": {},
    }
    return WEEKLY_PLANS.insert({**defaults, **fields, "week_start": week_start})
