"""
Reminders store — saved locally in data/reminders.json. Used by
friday/tools/reminders.py (MCP tools), assistant.py's background check, and
the HUD, so a reminder set one way shows up everywhere.
"""

from datetime import datetime

from friday.db.local_store import Table

_table = Table("reminders", timestamp_fields=("created_at",))
DUE_FORMAT = "%Y-%m-%d %H:%M"  # only the format we *write* in — see parse_due()


def parse_due(due_str: str) -> datetime:
    return datetime.fromisoformat(due_str)


def create_reminder(text: str, due: datetime) -> dict:
    return _table.insert({"text": text, "due": due.strftime(DUE_FORMAT), "done": False})


def list_reminders() -> list[dict]:
    upcoming = _table.where(lambda r: not r["done"])
    return sorted(upcoming, key=lambda r: parse_due(r["due"]))


def delete_reminder(reminder_id: int) -> bool:
    return _table.delete(reminder_id)


def list_todays_reminders() -> list[dict]:
    today = datetime.now().date()
    return [r for r in list_reminders() if parse_due(r["due"]).date() == today]


def list_all_due(now: datetime) -> list[dict]:
    """Not-yet-done reminders whose due time has passed."""
    return [r for r in list_reminders() if parse_due(r["due"]) <= now]


def mark_done(reminder_id: int) -> None:
    _table.update(reminder_id, done=True)
