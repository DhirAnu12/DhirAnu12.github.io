"""
Data resources — expose static content or dynamic data via MCP resources.
"""

from friday.settings import ASSISTANT_NAME


def register(mcp):

    @mcp.resource("friday://info")
    def server_info() -> str:
        """Returns basic info about this MCP server."""
        return (
            f"{ASSISTANT_NAME} MCP Server\n"
            "A Tony Stark-inspired personal AI assistant.\n"
            "Built with FastMCP."
        )
